import React, { useState } from 'react';
import { GameType } from '../types';
import { 
  Dice5, CircleDollarSign, Spade, Club, Gem, LayoutGrid, Hash, Tv, 
  Rocket, Bomb, Layers, ArrowLeft, BookOpen, Scroll, Armchair, ChevronRight 
} from 'lucide-react';

interface LobbyScreenProps {
  onSelectGame: (game: GameType) => void;
  userName: string;
  balance: number;
}

const MAIN_GAMES = [
  { id: GameType.ROULETTE, name: 'Grand Roulette', icon: CircleDollarSign, desc: 'European Wheel' },
  { id: GameType.ROCKET, name: 'High Altitude', icon: Rocket, desc: 'Crash Multiplier' },
  { id: GameType.MINES, name: 'Diamond Vault', icon: Bomb, desc: 'Minesweeper' },
  { id: GameType.SLOTS, name: 'Dynasty Slots', icon: LayoutGrid, desc: 'Classic 3-Reel' },
  { id: GameType.CRAPS, name: 'Craps Table', icon: Dice5, desc: 'Dice Wagering' },
  { id: GameType.KENO, name: 'Royal Keno', icon: Hash, desc: 'Number Draw' },
];

const CARD_GAMES = [
  { id: GameType.DURAK, name: 'Durak Imperial', icon: Scroll, desc: 'Russian Classic' },
  { id: GameType.BLACKJACK, name: 'Blackjack Privé', icon: Spade, desc: 'Standard Pays 3:2' },
  { id: GameType.POKER, name: 'Salon Poker', icon: Club, desc: 'Hold\'em Style' },
  { id: GameType.BACCARAT, name: 'Baccarat VIP', icon: Gem, desc: 'Punto Banco' },
  { id: GameType.VIDEO_POKER, name: 'Video Poker', icon: Tv, desc: 'Jacks or Better' },
];

const LobbyScreen: React.FC<LobbyScreenProps> = ({ onSelectGame, userName, balance }) => {
  const [currentView, setCurrentView] = useState<'MAIN' | 'CARDS'>('MAIN');

  const renderGameCard = (game: any) => (
    <button
      key={game.id}
      onClick={() => onSelectGame(game.id)}
      className="group relative w-full h-32 bg-[#0d0d0d] border border-white/5 overflow-hidden transition-all duration-300 hover:border-royal-gold/30 active:scale-[0.99] flex items-center"
    >
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-royal-gold/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      
      {/* Icon Area */}
      <div className="w-24 h-full flex items-center justify-center bg-white/5 border-r border-white/5 group-hover:bg-royal-gold/10 transition-colors">
         <game.icon className="text-royal-gold w-8 h-8 opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300" strokeWidth={1} />
      </div>

      {/* Text Area */}
      <div className="flex-1 px-5 flex flex-col items-start justify-center">
         <span className="font-cinzel font-bold text-om-cream text-lg tracking-wide group-hover:text-royal-gold transition-colors">
            {game.name}
         </span>
         <span className="font-cormorant text-white/30 text-xs uppercase tracking-wider mt-1">
            {game.desc}
         </span>
      </div>

      {/* Arrow */}
      <div className="pr-4 opacity-0 group-hover:opacity-50 transition-opacity -translate-x-2 group-hover:translate-x-0 duration-300">
         <ChevronRight className="text-royal-gold" size={16} />
      </div>
    </button>
  );

  return (
    <div className="flex flex-col h-screen w-full bg-om-wine bg-damask animate-fade-in overflow-hidden shadow-[inset_0_0_100px_black]">
      
      {/* VIP Header */}
      <div className="pt-safe px-6 pb-6 bg-gradient-to-b from-black via-black/90 to-transparent z-20">
        <div className="flex justify-between items-center mb-6">
            <div className="flex flex-col">
                 <span className="font-cinzel text-[10px] text-royal-gold/50 uppercase tracking-[0.2em] mb-1">Member</span>
                 <span className="font-playfair text-xl text-om-cream tracking-wide">{userName}</span>
            </div>
            <div className="flex flex-col items-end">
                <span className="font-cinzel text-[10px] text-royal-gold/50 uppercase tracking-[0.2em] mb-1">Credits</span>
                <span className="font-playfair text-2xl text-royal-gold font-bold gold-text">${balance.toLocaleString()}</span>
            </div>
        </div>

        {/* Navigation Switcher */}
        <div className="flex gap-4 border-b border-white/10 pb-1">
            <button 
                onClick={() => setCurrentView('MAIN')}
                className={`pb-2 text-xs font-cinzel tracking-[0.15em] transition-colors ${currentView === 'MAIN' ? 'text-royal-gold border-b border-royal-gold' : 'text-white/30 hover:text-white/60'}`}
            >
                MAIN FLOOR
            </button>
            <button 
                onClick={() => setCurrentView('CARDS')}
                className={`pb-2 text-xs font-cinzel tracking-[0.15em] transition-colors ${currentView === 'CARDS' ? 'text-royal-gold border-b border-royal-gold' : 'text-white/30 hover:text-white/60'}`}
            >
                CARD ROOM
            </button>
        </div>
      </div>

      {/* Scrollable List */}
      <div className="flex-1 overflow-y-auto px-4 pb-24 scrollbar-hide pt-2">
        <div className="flex flex-col gap-3 max-w-xl mx-auto">
          
          {currentView === 'MAIN' ? (
            <>
              {MAIN_GAMES.map(renderGameCard)}
              
              {/* Feature Card for Card Room */}
              <button
                onClick={() => setCurrentView('CARDS')}
                className="group relative w-full h-28 mt-4 bg-royal-green/20 border border-royal-green/30 overflow-hidden flex items-center justify-between px-6 shadow-inner"
              >
                 <div className="absolute inset-0 bg-felt-pattern opacity-30"></div>
                 <div className="relative z-10 flex flex-col items-start">
                    <span className="font-cinzel font-bold text-royal-gold text-lg tracking-widest">
                        Private Card Room
                    </span>
                    <span className="font-cormorant italic text-white/50 text-xs mt-1">
                        High Stakes: Poker, Blackjack, Baccarat
                    </span>
                 </div>
                 <div className="relative z-10 w-12 h-12 rounded-full border border-royal-green/50 flex items-center justify-center bg-black/20">
                    <BookOpen className="text-royal-green" size={20} />
                 </div>
              </button>
            </>
          ) : (
            <>
              {CARD_GAMES.map(renderGameCard)}
            </>
          )}

          {/* Footer Decoration */}
          <div className="flex justify-center py-8 opacity-20">
             <div className="h-px w-16 bg-royal-gold"></div>
             <div className="px-4 text-[10px] font-cinzel text-royal-gold">THE RESIDENCY</div>
             <div className="h-px w-16 bg-royal-gold"></div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default LobbyScreen;