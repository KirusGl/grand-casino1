import React, { useState, useEffect } from 'react';
import { createDeck, Card, evaluatePokerHand } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';
import BettingControls from '../shared/BettingControls';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const PokerGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [deck, setDeck] = useState<Card[]>([]);
    const [playerHand, setPlayerHand] = useState<Card[]>([]);
    const [dealerHand, setDealerHand] = useState<Card[]>([]);
    const [gameState, setGameState] = useState<'ANTE' | 'DECISION' | 'RESULT'>('ANTE');
    const [ante, setAnte] = useState(10);
    const [message, setMessage] = useState("Place Ante");

    useEffect(() => setDeck(createDeck()), []);

    const deal = () => {
        if (balance < ante) { setMessage("Insufficient funds"); return; }
        onUpdateBalance(-ante);
        
        let d = [...deck];
        if (d.length < 10) d = createDeck();
        const p = d.splice(0, 5);
        const dealer = d.splice(0, 5);
        setDeck(d);
        setPlayerHand(p);
        setDealerHand(dealer);
        setGameState('DECISION');
        setMessage("Call (2x Ante) or Fold?");
    };

    const fold = () => {
        setGameState('RESULT');
        setMessage("Folded. House Wins.");
    };

    const call = () => {
        const callAmount = ante * 2;
        if (balance < callAmount) {
            setMessage("Insufficient funds to Call");
            return;
        }
        onUpdateBalance(-callAmount);
        
        setGameState('RESULT');
        const pEval = evaluatePokerHand(playerHand);
        const dEval = evaluatePokerHand(dealerHand);
        
        let win = false;
        if (pEval.rank > dEval.rank) win = true;
        else if (pEval.rank === dEval.rank) win = true;

        if (win) {
            onUpdateBalance(ante * 2 + callAmount * 2);
            setMessage(`You Win! ${pEval.name}`);
        } else {
            setMessage(`House Wins with ${dEval.name}`);
        }
    };

    const reset = () => {
        setPlayerHand([]);
        setDealerHand([]);
        setGameState('ANTE');
        setMessage("Place Ante");
    };

    return (
        <div className="flex flex-col h-full p-4 items-center justify-between bg-royal-bg overflow-hidden w-full">
            <div className="text-royal-gold font-cormorant text-xl mt-4 text-center z-10">{message}</div>
            
            <div className="flex-1 w-full flex flex-col justify-center gap-[5vh]">
                
                {/* Dealer Hand */}
                <div className="flex flex-col items-center origin-top">
                    <div className="text-xs text-royal-gold/50 mb-2 uppercase tracking-widest bg-black/30 px-3 py-1 rounded-full">Dealer</div>
                    <div className="flex -space-x-[clamp(20px,6vw,40px)] justify-center">
                        {gameState === 'ANTE' ? (
                            <div className="w-full h-[clamp(70px,22vw,140px)] flex items-center justify-center border-2 border-dashed border-white/10 rounded-lg text-white/10 text-sm">Waiting...</div>
                        ) : (
                            dealerHand.map((c, i) => <PlayingCard key={i} card={c} hidden={gameState === 'DECISION' && i > 0} />)
                        )}
                    </div>
                </div>

                {/* Player Hand */}
                <div className="flex flex-col items-center">
                    <div className="flex -space-x-[clamp(20px,6vw,40px)] justify-center">
                        {playerHand.map((c, i) => <PlayingCard key={i} card={c} />)}
                        {playerHand.length === 0 && (
                            <div className="w-[clamp(50px,16vw,100px)] h-[clamp(70px,22vw,140px)] border-2 border-dashed border-white/10 rounded-lg"></div>
                        )}
                    </div>
                    {gameState !== 'ANTE' && (
                        <div className="text-xs text-royal-gold mt-3 font-bold uppercase bg-black/50 px-4 py-1 rounded-full border border-royal-gold/30">
                            {evaluatePokerHand(playerHand).name}
                        </div>
                    )}
                </div>
            </div>

            {gameState === 'ANTE' ? (
                <BettingControls 
                    balance={balance}
                    currentBet={ante}
                    onBetChange={setAnte}
                    onAction={deal}
                    actionLabel="DEAL HAND"
                />
            ) : gameState === 'DECISION' ? (
                <div className="w-full bg-royal-wood/95 border-t border-royal-gold/30 p-4 pb-safe flex gap-4 shadow-[0_-5px_20px_black]">
                    <button 
                        onClick={fold} 
                        className="flex-1 py-4 bg-gradient-to-br from-royal-red to-red-900 text-white font-black text-lg rounded-sm shadow-embossed active:scale-95 transition-all border border-white/10"
                    >
                        FOLD
                    </button>
                    <button 
                        onClick={call} 
                        className="flex-1 py-4 bg-gradient-to-br from-royal-gold to-[#8a6e2f] text-black font-black text-lg rounded-sm shadow-embossed active:scale-95 transition-all border border-white/10"
                    >
                        CALL ({ante * 2})
                    </button>
                </div>
            ) : (
                <div className="w-full bg-royal-wood/95 border-t border-royal-gold/30 p-4 pb-safe shadow-[0_-5px_20px_black]">
                    <button 
                        onClick={reset} 
                        className="w-full py-4 bg-gradient-to-br from-royal-gold to-[#8a6e2f] text-black font-black text-lg rounded-sm shadow-embossed active:scale-95 transition-all border border-white/10"
                    >
                        NEW HAND
                    </button>
                </div>
            )}
        </div>
    );
};

export default PokerGame;