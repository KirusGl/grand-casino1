import React, { useState, useRef } from 'react';
import { Card, createDurakDeck, shuffle } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';
import BettingControls from '../shared/BettingControls';

interface Props {
  balance: number;
  onUpdateBalance: (delta: number) => void;
}

interface TablePair {
  attack: Card;
  defense: Card | null;
}

const DurakGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [aiHand, setAiHand] = useState<Card[]>([]);
  const [table, setTable] = useState<TablePair[]>([]);
  const [trump, setTrump] = useState<Card | null>(null);
  const [attacker, setAttacker] = useState<'PLAYER' | 'AI'>('PLAYER');
  const [isPlayerTurn, setIsPlayerTurn] = useState(false);
  const [message, setMessage] = useState('Durak');
  const [gameActive, setGameActive] = useState(false);
  const [bet, setBet] = useState(10);

  const handContainerRef = useRef<HTMLDivElement>(null);

  const startGame = () => {
    if (balance < bet) {
        setMessage("Insufficient Funds");
        return;
    }
    onUpdateBalance(-bet);

    let newDeck = shuffle(createDurakDeck());
    const trumpCard = newDeck[newDeck.length - 1];
    newDeck = newDeck.slice(0, -1);
    const p = newDeck.splice(0, 6);
    const ai = newDeck.splice(0, 6);
    setDeck(newDeck);
    setPlayerHand(p);
    setAiHand(ai);
    setTrump(trumpCard);
    setAttacker('PLAYER'); 
    setIsPlayerTurn(true);
    setTable([]);
    setGameActive(true);
    setMessage('Your Turn');
  };

  const handleCardClick = (index: number) => {
      if(!isPlayerTurn || !gameActive) return;
      const card = playerHand[index];
      setTable([...table, {attack: card, defense: null}]);
      setPlayerHand(playerHand.filter((_, i) => i !== index));
      
      if (playerHand.length <= 1 && deck.length === 0) {
          setGameActive(false);
          onUpdateBalance(bet * 2);
          setMessage("You Won!");
          return;
      }

      setTimeout(() => {
          setMessage("AI Thinking...");
          setIsPlayerTurn(false);
          setTimeout(() => {
              setMessage("Your Turn");
              setIsPlayerTurn(true);
          }, 1000);
      }, 500);
  };

  const takeCards = () => {
      setMessage("Cards Taken");
      setTable([]);
      setIsPlayerTurn(false);
      setTimeout(() => {
          setIsPlayerTurn(true); 
          setMessage("Your Turn");
      }, 1000);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#050a08] relative overflow-hidden">
        
        {/* Top Info Bar */}
        <div className="flex justify-between px-4 py-2 text-[10px] md:text-xs text-royal-gold/60 uppercase tracking-widest bg-black/40 border-b border-white/5 z-20">
            <span>Deck: {deck.length}</span>
            <span>Opponent: {aiHand.length} cards</span>
        </div>

        {/* AI Area (Top) */}
        {/* АДАПТИВ: Скрываем карты AI частично за пределом экрана, чтобы не занимать место */}
        <div className="h-[12vh] w-full flex justify-center items-start pt-2 -space-x-[clamp(10px,2vw,20px)] opacity-80">
            {aiHand.map((_, i) => (
                <div key={i} className="w-[clamp(30px,10vw,50px)] h-[clamp(45px,15vw,75px)] bg-royal-wood border border-royal-gold/30 rounded-sm shadow-md" />
            ))}
        </div>

        {/* Table Area (Middle) */}
        <div className="flex-1 flex items-center justify-center w-full relative z-10">
            {trump && (
                <div className="absolute left-2 top-1/2 -translate-y-1/2 opacity-50 scale-75 origin-left pointer-events-none">
                    <PlayingCard card={trump} className="rotate-90" />
                </div>
            )}

            {/* АДАПТИВ: Flex-wrap для стола, чтобы карты переносились при нехватке места */}
            <div className="flex gap-[2vw] flex-wrap justify-center content-center max-w-[85%] max-h-[40vh] overflow-y-auto scrollbar-hide">
                {table.map((pair, i) => (
                    <div key={i} className="relative w-[clamp(50px,16vw,100px)] h-[clamp(70px,22.4vw,140px)]">
                        <div className="absolute inset-0 transform transition-transform">
                             <PlayingCard card={pair.attack} className="w-full h-full" />
                        </div>
                        {pair.defense && (
                            <div className="absolute inset-0 transform translate-x-[15%] translate-y-[15%] z-20 shadow-[0_5px_15px_rgba(0,0,0,0.5)]">
                                <PlayingCard card={pair.defense} className="w-full h-full" />
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>

        {/* Message Toast */}
        <div className="absolute top-[45%] left-1/2 -translate-x-1/2 pointer-events-none z-30 w-max max-w-[90%] text-center">
            <span className="bg-black/90 px-6 py-2 rounded-full text-royal-gold border border-royal-gold/50 text-sm font-playfair backdrop-blur-md shadow-lg">{message}</span>
        </div>

        {/* Player Hand Scrollable Container */}
        <div 
            ref={handContainerRef}
            className="w-full h-[clamp(100px,28vh,220px)] flex items-end justify-center overflow-x-auto overflow-y-hidden px-4 pb-safe scrollbar-hide z-20"
        >
            <div className="flex items-end -space-x-[clamp(20px,8vw,50px)] min-w-min px-[5vw] pb-2">
                {playerHand.map((c, i) => (
                    <div 
                        key={i} 
                        onClick={() => handleCardClick(i)}
                        className="transition-transform duration-200 hover:-translate-y-4 active:scale-95 origin-bottom z-auto hover:z-50"
                    >
                        <PlayingCard card={c} selected={false} className="shadow-[0_-2px_10px_rgba(0,0,0,0.5)]" />
                    </div>
                ))}
            </div>
        </div>
        
        {/* Controls Overlay */}
        {!gameActive ? (
            <div className="absolute inset-x-0 bottom-0 z-50">
                 <BettingControls 
                    balance={balance}
                    currentBet={bet}
                    onBetChange={setBet}
                    onAction={startGame}
                    actionLabel="DEAL CARDS"
                 />
            </div>
        ) : (
            isPlayerTurn && (
                <div className="absolute bottom-[28vh] right-4 z-40">
                    <button 
                        onClick={takeCards}
                        className="bg-royal-wood border border-royal-gold/50 text-white px-6 py-3 rounded-full shadow-xl text-xs font-bold uppercase tracking-wider hover:bg-royal-gold hover:text-black transition-colors active:scale-95"
                    >
                        {attacker === 'PLAYER' ? 'Done' : 'Take'}
                    </button>
                </div>
            )
        )}
    </div>
  );
};

export default DurakGame;