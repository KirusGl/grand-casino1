import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Rocket, AlertTriangle } from 'lucide-react';
import BettingControls from '../shared/BettingControls';

interface Props {
  balance: number;
  onUpdateBalance: (delta: number) => void;
}

type GameState = 'IDLE' | 'COUNTDOWN' | 'FLYING' | 'CRASHED' | 'CASHED_OUT';

const RocketGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
  const [status, setStatus] = useState<GameState>('IDLE');
  const [multiplier, setMultiplier] = useState(1);
  const [bet, setBet] = useState(10);
  const [crashPoint, setCrashPoint] = useState(0);
  const [countDown, setCountDown] = useState(3);

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(0);
  const startTimeRef = useRef<number>(0);

  // АДАПТИВ: Обновление размеров Canvas при ресайзе с учетом Device Pixel Ratio
  const updateCanvasSize = useCallback(() => {
    if (containerRef.current && canvasRef.current) {
      const { width, height } = containerRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvasRef.current.width = width * dpr;
      canvasRef.current.height = height * dpr;
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) ctx.scale(dpr, dpr);
      canvasRef.current.style.width = `${width}px`;
      canvasRef.current.style.height = `${height}px`;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('resize', updateCanvasSize);
    updateCanvasSize();
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, [updateCanvasSize]);

  const placeBet = () => {
    if (balance < bet || bet <= 0) return;
    onUpdateBalance(-bet);
    setCrashPoint((Math.random() * 5) + 1.1); 
    setMultiplier(1);
    setCountDown(3);
    setStatus('COUNTDOWN');
    // Clear canvas
    if (canvasRef.current && containerRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        const { width, height } = containerRef.current.getBoundingClientRect();
        ctx?.clearRect(0, 0, width, height);
    }
  };

  const cashOut = () => {
    if (status !== 'FLYING') return;
    cancelAnimationFrame(requestRef.current);
    const win = Math.floor(bet * multiplier);
    onUpdateBalance(win);
    setStatus('CASHED_OUT');
  };

  const reset = () => {
      setStatus('IDLE');
      setMultiplier(1);
  };

  useEffect(() => {
    if (status === 'COUNTDOWN') {
      if (countDown > 0) {
        const t = setTimeout(() => setCountDown(c => c - 1), 1000);
        return () => clearTimeout(t);
      } else {
        setStatus('FLYING');
        startTimeRef.current = performance.now();
        startAnimation();
      }
    }
  }, [status, countDown]);

  const startAnimation = () => {
    const animate = (time: number) => {
      const elapsed = (time - startTimeRef.current) / 1000;
      const nextMult = 1 + Math.pow(elapsed, 1.8) * 0.35;

      if (nextMult >= crashPoint) {
        setMultiplier(crashPoint);
        setStatus('CRASHED');
        cancelAnimationFrame(requestRef.current);
        return;
      }

      setMultiplier(nextMult);
      drawScene(nextMult, elapsed);
      requestRef.current = requestAnimationFrame(animate);
    };
    requestRef.current = requestAnimationFrame(animate);
  };

  const drawScene = (currentMult: number, elapsed: number) => {
    const canvas = canvasRef.current;
    if (!canvas || !containerRef.current) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width: w, height: h } = containerRef.current.getBoundingClientRect();
    ctx.clearRect(0, 0, w, h);

    // АДАПТИВ: Безопасные отступы относительно размеров экрана
    const paddingX = w * 0.1;
    const paddingY = h * 0.15;
    
    // АДАПТИВ: Клампинг координат для предотвращения выхода за границы
    const rawX = elapsed * (w * 0.15);
    const rawY = (currentMult - 1) * (h * 0.6);
    
    // Логика ограничения координат:
    // X не может уйти дальше (ширина - паддинг)
    // Y инвертирован (растет вверх), ограничиваем чтобы не ушел в минус
    const x = Math.min(w - paddingX, rawX); 
    const y = h - Math.min(h - paddingY, rawY);

    // Grid
    ctx.strokeStyle = '#222';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < w; i += w/8) { ctx.moveTo(i, 0); ctx.lineTo(i, h); }
    for (let i = 0; i < h; i += h/5) { ctx.moveTo(0, i); ctx.lineTo(w, i); }
    ctx.stroke();

    // Trajectory
    const gradient = ctx.createLinearGradient(x, y, 0, h);
    gradient.addColorStop(0, '#d4af37');
    gradient.addColorStop(1, 'rgba(212, 175, 55, 0.1)');
    
    ctx.beginPath();
    ctx.moveTo(0, h);
    // Кривая Безье для плавности
    ctx.quadraticCurveTo(x / 2, h, x, y);
    ctx.strokeStyle = '#d4af37';
    ctx.lineWidth = Math.max(2, w * 0.005);
    ctx.lineCap = 'round';
    ctx.stroke();
    
    // Заливка под графиком
    ctx.lineTo(x, h);
    ctx.fillStyle = gradient;
    ctx.fill();

    // Rocket Icon/Circle
    const rocketSize = Math.max(4, w * 0.012);
    ctx.beginPath();
    ctx.arc(x, y, rocketSize, 0, Math.PI * 2);
    ctx.fillStyle = '#f8f3e6';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#d4af37';
    ctx.fill();
    ctx.shadowBlur = 0;
  };

  return (
    <div className="flex flex-col h-full w-full overflow-hidden bg-royal-bg text-royal-ivory">
      
      <div ref={containerRef} className="flex-1 relative flex items-center justify-center overflow-hidden w-full bg-[#0a0a0a]">
        <canvas ref={canvasRef} className="absolute inset-0 block touch-none" />
        
        {/* АДАПТИВ: Текст с clamp шрифтом */}
        <div className="z-10 text-center pointer-events-none select-none">
            {status === 'COUNTDOWN' && (
               <div className="font-black text-royal-gold animate-pulse text-[clamp(4rem,15vw,8rem)] drop-shadow-[0_0_15px_rgba(212,175,55,0.5)]">
                   {countDown}
               </div>
            )}
            {(status === 'FLYING' || status === 'CASHED_OUT') && (
               <div className={`font-black tracking-tighter text-[clamp(4rem,12vw,6rem)] leading-none tabular-nums ${
                 status === 'CASHED_OUT' ? 'text-green-500' : 'text-royal-gold'
               }`}>
                 {multiplier.toFixed(2)}x
               </div>
            )}
             {status === 'CRASHED' && (
               <div className="flex flex-col items-center animate-bounce">
                  <AlertTriangle className="text-royal-red w-[clamp(50px,15vw,80px)] h-[clamp(50px,15vw,80px)]" />
                  <div className="font-black text-royal-red text-[clamp(2rem,8vw,4rem)]">CRASHED</div>
                  <div className="text-royal-gold text-[clamp(1rem,4vw,1.5rem)]">@{multiplier.toFixed(2)}x</div>
               </div>
            )}
        </div>
      </div>

      {status === 'IDLE' || status === 'CRASHED' || status === 'CASHED_OUT' ? (
          <BettingControls 
            balance={balance}
            currentBet={bet}
            onBetChange={setBet}
            onAction={placeBet}
            actionLabel="LAUNCH"
          />
      ) : (
         <div className="w-full bg-royal-wood/95 border-t border-royal-gold/30 p-4 pb-safe z-40">
            <button 
                onClick={cashOut} 
                className="w-full py-4 bg-gradient-to-r from-green-800 to-green-600 text-white font-black text-[clamp(1.2rem,5vw,1.5rem)] rounded-sm shadow-embossed hover:brightness-110 active:scale-95 transition-all border border-white/20"
            >
                CASH OUT {(bet * multiplier).toFixed(0)}
            </button>
         </div>
      )}
    </div>
  );
};

export default RocketGame;