import React, { useState } from 'react';
import { CHIP_VALUES } from '../../constants';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6 } from 'lucide-react';
import BettingControls from '../shared/BettingControls';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const CrapsGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [point, setPoint] = useState<number | null>(null);
    const [bet, setBet] = useState(10);
    const [dice, setDice] = useState([1, 1]);
    const [rolling, setRolling] = useState(false);
    const [message, setMessage] = useState("Pass Line Bet");

    const DiceIcon = [Dice1, Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];

    const roll = () => {
        if (bet === 0) { setMessage("Place Bet"); return; }
        // If it's a new game (point is null), we deduct bet now
        // But simplifying: betting controls sets the 'stake'. We deduct on Roll if not already deducted?
        // Let's deduct immediately on Roll start for simplicity.
        if (balance < bet) { setMessage("Low Balance"); return; }
        
        if (point === null) onUpdateBalance(-bet); // Initial bet deduction
        
        setRolling(true);
        let count = 0;
        const interval = setInterval(() => {
            setDice([Math.ceil(Math.random() * 6), Math.ceil(Math.random() * 6)]);
            count++;
            if (count > 10) {
                clearInterval(interval);
                finishRoll();
            }
        }, 100);
    };

    const finishRoll = () => {
        setRolling(false);
        const d1 = Math.ceil(Math.random() * 6);
        const d2 = Math.ceil(Math.random() * 6);
        setDice([d1, d2]);
        const total = d1 + d2;
        
        if (point === null) {
            // Come Out Roll
            if (total === 7 || total === 11) {
                win(bet * 2);
            } else if (total === 2 || total === 3 || total === 12) {
                lose();
            } else {
                setPoint(total);
                setMessage(`Point is ${total}. Roll ${total} to win!`);
            }
        } else {
            // Point Phase
            if (total === point) {
                win(bet * 2);
                setPoint(null);
            } else if (total === 7) {
                lose();
                setPoint(null);
            } else {
                setMessage(`Rolled ${total}. Point is ${point}.`);
            }
        }
    };

    const win = (amount: number) => {
        onUpdateBalance(amount);
        setMessage("YOU WIN!");
        // Bet remains for next round logic? Or clear? Let's keep bet amount in controls but game resets.
    };

    const lose = () => {
        setMessage("CRAPS! You Lose.");
    };

    return (
        <div className="flex flex-col h-full items-center justify-between w-full bg-royal-bg">
             <div className="flex-1 flex flex-col items-center justify-center w-full">
                <div className="text-3xl font-playfair text-royal-gold mb-8 text-center px-4 animate-fade-in">{message}</div>
                
                <div className="flex gap-4 mb-12 transform scale-125">
                    <div className="w-20 h-20 bg-royal-ivory rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                        {React.createElement(DiceIcon[dice[0]], { size: 56 })}
                    </div>
                    <div className="w-20 h-20 bg-royal-ivory rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                        {React.createElement(DiceIcon[dice[1]], { size: 56 })}
                    </div>
                </div>

                {point !== null && (
                    <div className="bg-royal-wood border border-royal-gold/30 px-6 py-2 rounded-full mb-4">
                        <span className="text-royal-gold/60 text-xs uppercase tracking-widest mr-2">Target Point</span>
                        <span className="text-2xl font-bold text-royal-gold">{point}</span>
                    </div>
                )}
             </div>

             <BettingControls 
                balance={balance}
                currentBet={bet}
                onBetChange={setBet}
                onAction={roll}
                actionLabel={rolling ? "ROLLING..." : (point ? "ROLL DICE" : "ROLL (PASS LINE)")}
                isGameActive={rolling || point !== null} 
                // We lock bet amount change while Point is active for simplicity
             />
        </div>
    );
};

export default CrapsGame;