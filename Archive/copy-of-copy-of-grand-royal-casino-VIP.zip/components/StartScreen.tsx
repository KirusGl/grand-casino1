import React from 'react';
import { KeyRound, Crown, Shield } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
  userName: string;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart, userName }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen w-full bg-om-leather bg-vip-leather relative p-6 text-center animate-fade-in shadow-[inset_0_0_150px_rgba(0,0,0,1)]">
      
      {/* Decorative ambient glow */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-royal-gold/5 to-transparent pointer-events-none" />
      
      {/* Border Frame */}
      <div className="absolute inset-4 border border-om-gold/10 rounded-xl pointer-events-none z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-om-leather px-4">
               <Crown size={16} className="text-om-gold/40" />
          </div>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 bg-om-leather px-4 text-[10px] text-om-gold/30 tracking-[0.3em] font-cinzel">
               MCMXCVII
          </div>
      </div>

      {/* Main Content Card */}
      <div className="relative z-20 w-full max-w-sm">
        
        <div className="mb-12 relative">
             <div className="absolute inset-0 bg-om-gold/20 blur-[50px] rounded-full opacity-20"></div>
             <h1 className="relative text-5xl md:text-6xl font-cinzel font-black tracking-widest uppercase text-transparent bg-clip-text bg-gold-gradient drop-shadow-lg">
                The<br/>Residency
             </h1>
             <p className="mt-4 font-cormorant text-om-cream/60 italic text-lg tracking-wide">
                "Fortuna Audaces Juvat"
             </p>
        </div>

        {/* Invitation Ticket Look */}
        <div className="bg-black/40 backdrop-blur-md border border-om-gold/10 p-1 rounded-sm shadow-2xl mb-12 transform transition-transform hover:scale-[1.01]">
            <div className="border border-om-gold/20 p-6 flex flex-col items-center">
                <div className="text-[10px] font-playfair text-om-gold/50 uppercase tracking-[0.2em] mb-4">
                  Private Access Granted For
                </div>
                <div className="font-playfair text-2xl md:text-3xl text-om-cream border-b border-om-gold/30 pb-2 mb-2 min-w-[200px]">
                   {userName}
                </div>
                <div className="flex items-center gap-2 mt-2 opacity-50">
                    <Shield size={12} className="text-om-gold" />
                    <span className="text-[10px] uppercase tracking-widest text-om-gold">Member ID: {Math.floor(Math.random() * 10000).toString().padStart(4, '0')}</span>
                </div>
            </div>
        </div>

        {/* Action Button */}
        <button
          onClick={onStart}
          className="group relative w-full py-5 overflow-hidden rounded-sm shadow-[0_10px_30px_-10px_rgba(0,0,0,0.8)] active:scale-[0.98] transition-all"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-om-gold/80 to-[#8a6e2f] opacity-90 group-hover:opacity-100 transition-opacity"></div>
          
          {/* Shine effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
          
          <span className="relative z-10 font-cinzel text-xl text-[#1a0f0f] font-bold flex items-center justify-center gap-3 tracking-[0.15em]">
             ENTER SALON <KeyRound size={20} strokeWidth={2.5} />
          </span>
        </button>

      </div>

      <div className="absolute bottom-8 opacity-20">
        <p className="font-cinzel text-[9px] text-om-cream uppercase tracking-[0.3em]">
           Members Only • Dress Code: Black Tie
        </p>
      </div>
    </div>
  );
};

export default StartScreen;