import React from 'react';
import { Card } from '../../utils/cardUtils';
import { Heart, Diamond, Club, Spade } from 'lucide-react';

interface PlayingCardProps {
  card?: Card;
  hidden?: boolean;
  className?: string;
  selected?: boolean;
  onClick?: () => void;
}

const PlayingCard: React.FC<PlayingCardProps> = ({ card, hidden, className = '', selected, onClick }) => {
  // АДАПТИВ: Использование clamp() для гарантии читаемости на всех устройствах
  // min: 50px/70px (старые SE), preferred: 16vw/22vw, max: 100px/140px (планшеты/десктоп)
  const dimensions = "w-[clamp(50px,16vw,100px)] h-[clamp(70px,22.4vw,140px)]";
  
  const baseClasses = `
    relative rounded-lg shadow-xl select-none transition-transform duration-200
    ${dimensions}
    flex items-center justify-center overflow-hidden border border-gray-200
    bg-[#fdfbf7]
    ${selected ? 'ring-2 ring-royal-gold -translate-y-2 z-10' : 'hover:-translate-y-1'}
    ${onClick ? 'cursor-pointer active:scale-95' : ''}
    ${className}
  `;

  // Back of card
  if (hidden || !card) {
    return (
      <div className={`${baseClasses} bg-[#1a1a1a] border-white/10`}>
        <div className="absolute inset-1 border border-royal-gold/40 rounded opacity-80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-royal-gold/20 via-transparent to-transparent" />
        {/* АДАПТИВ: Размер шрифта логотипа масштабируется вместе с картой */}
        <div className="text-royal-gold font-playfair font-bold text-[clamp(1rem,4vw,2rem)]">R</div>
      </div>
    );
  }

  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';
  const Icon = card.suit === 'hearts' ? Heart : card.suit === 'diamonds' ? Diamond : card.suit === 'clubs' ? Club : Spade;

  return (
    <div onClick={onClick} className={`${baseClasses}`}>
      {/* АДАПТИВ: Отступы в % для сохранения пропорций */}
      <div className={`absolute top-[6%] left-[6%] flex flex-col items-center leading-none ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
        {/* АДАПТИВ: Шрифт ранга */}
        <span className="font-playfair font-bold text-[clamp(0.6rem,2.5vw,1.2rem)]">{card.rank}</span>
        {/* АДАПТИВ: Размер иконки масти */}
        <Icon className="w-[clamp(8px,2.5vw,16px)] h-[clamp(8px,2.5vw,16px)] mt-[2px]" fill="currentColor" />
      </div>

      <div className={`flex items-center justify-center ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
         {['J', 'Q', 'K', 'A'].includes(card.rank) ? (
             <div className="font-playfair font-black text-[clamp(1.2rem,5vw,2.5rem)] opacity-90 border-2 border-current rounded px-1">
                 {card.rank}
             </div>
         ) : (
             <Icon className="w-[clamp(24px,8vw,48px)] h-[clamp(24px,8vw,48px)]" fill="currentColor" />
         )}
      </div>

      <div className={`absolute bottom-[6%] right-[6%] flex flex-col items-center leading-none rotate-180 ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
        <span className="font-playfair font-bold text-[clamp(0.6rem,2.5vw,1.2rem)]">{card.rank}</span>
        <Icon className="w-[clamp(8px,2.5vw,16px)] h-[clamp(8px,2.5vw,16px)] mt-[2px]" fill="currentColor" />
      </div>
    </div>
  );
};

export default PlayingCard;