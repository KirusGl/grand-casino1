import React, { useEffect, useState } from 'react';
import { CHIP_VALUES } from '../../constants';
import { Plus, Minus } from 'lucide-react';

interface BettingControlsProps {
  balance: number;
  currentBet: number;
  onBetChange: (amount: number) => void;
  onAction?: () => void;
  actionLabel?: string; 
  isGameActive?: boolean;
  minBet?: number;
  maxBet?: number;
  chipMode?: boolean; 
  children?: React.ReactNode; 
}

const BettingControls: React.FC<BettingControlsProps> = ({
  balance,
  currentBet,
  onBetChange,
  onAction,
  actionLabel = "PLAY",
  isGameActive = false,
  minBet = 10,
  maxBet = balance,
  chipMode = false,
  children
}) => {
  const [inputValue, setInputValue] = useState(currentBet.toString());

  useEffect(() => {
    setInputValue(currentBet.toString());
  }, [currentBet]);

  const handleValidation = (val: number) => {
    if (isNaN(val)) return;
    let newBet = Math.max(0, val);
    if (!chipMode) {
        newBet = Math.min(newBet, balance);
    }
    onBetChange(newBet);
  };

  const handleManualInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    const val = parseInt(e.target.value);
    if (!isNaN(val)) handleValidation(val);
  };

  const adjustBet = (delta: number) => handleValidation(currentBet + delta);
  const setExactBet = (amount: number) => handleValidation(amount);
  const handleMax = () => handleValidation(balance);

  return (
    // Panel: Dark Mahogany Wood
    <div className="w-full bg-[#1a0f0f] bg-wood-pattern border-t border-royal-gold/20 p-4 pb-safe shadow-[0_-15px_40px_rgba(0,0,0,0.9)] z-40 relative">
      <div className="max-w-md mx-auto w-full flex flex-col gap-4">
        
        {children && <div className="mb-1">{children}</div>}

        {/* Chip/Preset Row */}
        <div className="flex justify-between gap-3 overflow-x-auto scrollbar-hide py-1">
          {CHIP_VALUES.map((val) => (
            <button
              key={val}
              disabled={isGameActive}
              onClick={() => setExactBet(val)}
              className={`
                flex-1 min-w-[3.5rem] h-12 rounded-full font-bold font-playfair text-sm transition-all duration-300
                flex items-center justify-center border shadow-lg
                ${currentBet === val 
                  ? 'bg-gradient-to-br from-royal-gold to-[#8a6e2f] text-black border-white/40 scale-105 shadow-gold-glow' 
                  : 'bg-[#0f0a08] text-royal-gold border-royal-gold/20 hover:border-royal-gold/50'}
              `}
            >
              {val}
            </button>
          ))}
          {!chipMode && (
             <button 
                onClick={handleMax}
                disabled={isGameActive} 
                className="px-4 h-12 rounded-lg bg-white/5 border border-white/10 text-royal-gold/70 font-cinzel text-[10px] tracking-widest hover:bg-white/10 transition-colors uppercase"
             >
                MAX
             </button>
          )}
        </div>

        {/* Input & Action Row */}
        <div className="flex gap-3 h-14">
            {/* Input Group - Dark Metal */}
            <div className="flex-1 flex bg-black/60 rounded-sm border border-white/10 shadow-inner relative">
                <button 
                    onClick={() => adjustBet(-10)} 
                    disabled={isGameActive || currentBet <= minBet}
                    className="w-12 flex items-center justify-center text-white/30 hover:text-royal-gold active:bg-white/5 transition-colors border-r border-white/5"
                >
                    <Minus size={16} />
                </button>
                
                <div className="flex-1 relative flex items-center justify-center">
                    <span className="absolute left-3 text-white/20 font-serif italic">$</span>
                    <input
                        type="number"
                        value={inputValue}
                        onChange={handleManualInput}
                        disabled={isGameActive}
                        className="w-full h-full bg-transparent text-center text-om-cream font-playfair font-bold text-xl outline-none px-4"
                        placeholder="0"
                    />
                </div>

                <button 
                    onClick={() => adjustBet(10)} 
                    disabled={isGameActive || (!chipMode && currentBet >= balance)}
                    className="w-12 flex items-center justify-center text-white/30 hover:text-royal-gold active:bg-white/5 transition-colors border-l border-white/5"
                >
                    <Plus size={16} />
                </button>
            </div>

            {/* Action Button - Gold Ingot */}
            {onAction && (
                <button
                    onClick={onAction}
                    disabled={isGameActive || (!chipMode && (currentBet > balance || currentBet < minBet))}
                    className={`
                        flex-[1.3] rounded-sm font-cinzel font-bold text-lg tracking-widest shadow-lg transition-all active:scale-[0.98] flex items-center justify-center relative overflow-hidden
                        ${isGameActive 
                            ? 'bg-white/10 text-white/20 cursor-not-allowed border border-white/5' 
                            : 'bg-gradient-to-b from-[#d4af37] via-[#c5a059] to-[#8a6e2f] text-[#1a0f0f] hover:brightness-110 shadow-gold-glow border border-white/20'}
                    `}
                >
                    {actionLabel}
                    {/* Gloss effect */}
                    {!isGameActive && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-shimmer"></div>}
                </button>
            )}
        </div>
        
      </div>
    </div>
  );
};

export default BettingControls;