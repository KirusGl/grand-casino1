import React from 'react';
import { GameType } from '../types';
import { ArrowLeft, X } from 'lucide-react';
import RouletteGame from './games/RouletteGame';
import BlackjackGame from './games/BlackjackGame';
import SlotsGame from './games/SlotsGame';
import PokerGame from './games/PokerGame';
import BaccaratGame from './games/BaccaratGame';
import CrapsGame from './games/CrapsGame';
import VideoPokerGame from './games/VideoPokerGame';
import KenoGame from './games/KenoGame';
import RocketGame from './games/RocketGame';
import MinesGame from './games/MinesGame';
import DurakGame from './games/DurakGame';

interface GameScreenProps {
  gameType: GameType;
  balance: number;
  onUpdateBalance: (delta: number) => void;
  onBackToLobby: () => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ gameType, balance, onUpdateBalance, onBackToLobby }) => {
  
  const renderGame = () => {
    const props = {
      balance,
      onUpdateBalance,
    };

    switch (gameType) {
      case GameType.ROULETTE: return <RouletteGame {...props} />;
      case GameType.BLACKJACK: return <BlackjackGame {...props} />;
      case GameType.SLOTS: return <SlotsGame {...props} />;
      case GameType.POKER: return <PokerGame {...props} />;
      case GameType.BACCARAT: return <BaccaratGame {...props} />;
      case GameType.CRAPS: return <CrapsGame {...props} />;
      case GameType.VIDEO_POKER: return <VideoPokerGame {...props} />;
      case GameType.KENO: return <KenoGame {...props} />;
      case GameType.ROCKET: return <RocketGame {...props} />;
      case GameType.MINES: return <MinesGame {...props} />;
      case GameType.DURAK: return <DurakGame {...props} />;
      default: return <div>Game Under Construction</div>;
    }
  };

  return (
    // Outer Shell - Expensive dark leather texture
    <div className="flex flex-col h-screen bg-om-leather bg-vip-leather overflow-hidden relative shadow-inner">
        
      {/* Top Bar - Minimalist and Dark */}
      <div className="relative z-30 pt-safe px-4 pb-2 bg-black/80 backdrop-blur-md border-b border-white/5 shadow-2xl">
        <div className="flex justify-between items-center h-12">
            
            <button 
                onClick={onBackToLobby} 
                className="flex items-center gap-2 text-white/50 hover:text-royal-gold transition-colors"
            >
                <ArrowLeft size={20} strokeWidth={1.5} />
            </button>
            
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pt-safe">
                 <span className="font-cinzel text-royal-gold/90 text-sm tracking-[0.2em] uppercase">
                    {gameType.replace('_', ' ')}
                 </span>
            </div>

            <div className="flex items-center gap-3">
               <div className="text-right">
                   <span className="block font-playfair font-bold text-om-cream text-lg leading-none tracking-wide">${balance.toLocaleString()}</span>
               </div>
            </div>
        </div>
      </div>

      {/* Game Content - The Stage */}
      <div className="flex-1 overflow-hidden relative bg-[#050505] shadow-inner">
         {/* Subtle table texture overlay if needed, handled by individual games mostly, but we add a vignette here */}
         <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_80px_black] z-10"></div>
         
         {/* Background pattern for generic games */}
         <div className="absolute inset-0 opacity-20 bg-luxury-pattern pointer-events-none"></div>

         <div className="relative z-0 h-full w-full">
            {renderGame()}
         </div>
      </div>
    </div>
  );
};

export default GameScreen;