import React, { useState, useEffect } from 'react';
import { GameState, GameType } from './types';
import StartScreen from './components/StartScreen';
import LobbyScreen from './components/LobbyScreen';
import GameScreen from './components/GameScreen';
import ResultScreen from './components/ResultScreen';
import { initTelegram, getUserName } from './utils/telegram';
import { INITIAL_BALANCE } from './constants';

function App() {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [userName, setUserName] = useState<string>("Guest");
  const [selectedGame, setSelectedGame] = useState<GameType>(GameType.ROULETTE);
  const [balance, setBalance] = useState(INITIAL_BALANCE);

  useEffect(() => {
    initTelegram();
    setUserName(getUserName());
  }, []);

  const handleStart = () => {
    setGameState(GameState.LOBBY);
  };

  const handleSelectGame = (game: GameType) => {
    setSelectedGame(game);
    setGameState(GameState.PLAYING);
  };

  const handleUpdateBalance = (delta: number) => {
    setBalance(prev => prev + delta);
  };

  const handleBackToLobby = () => {
    setGameState(GameState.LOBBY);
  };

  const handleRestart = () => {
    setBalance(INITIAL_BALANCE);
    setGameState(GameState.LOBBY);
  };

  return (
    <div className="min-h-screen font-sans selection:bg-royal-gold selection:text-royal-black bg-royal-bg text-royal-ivory">
      {gameState === GameState.START && (
        <StartScreen onStart={handleStart} userName={userName} />
      )}
      
      {gameState === GameState.LOBBY && (
        <LobbyScreen 
          onSelectGame={handleSelectGame} 
          userName={userName} 
          balance={balance}
        />
      )}
      
      {gameState === GameState.PLAYING && (
        <GameScreen 
          gameType={selectedGame} 
          balance={balance}
          onUpdateBalance={handleUpdateBalance} 
          onBackToLobby={handleBackToLobby} 
        />
      )}

      {/* ResultScreen is technically unreachable via standard navigation now, 
          unless we add a specific "Cash Out" button in the future. 
          Keeping it for potential "Game Over" states if balance hits 0. */}
      {gameState === GameState.RESULT && (
        <ResultScreen 
          finalBalance={balance} 
          totalWon={balance - INITIAL_BALANCE}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}

export default App;