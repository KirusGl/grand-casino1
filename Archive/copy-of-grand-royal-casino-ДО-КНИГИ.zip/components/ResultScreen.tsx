import React from 'react';
import { RefreshCw, CheckCircle } from 'lucide-react';

interface ResultScreenProps {
  finalBalance: number;
  totalWon: number;
  onRestart: () => void;
}

const ResultScreen: React.FC<ResultScreenProps> = ({ finalBalance, totalWon, onRestart }) => {
  const isProfit = totalWon > 0;

  return (
    <div className="flex flex-col items-center justify-center h-screen w-full bg-royal-bg bg-felt-pattern relative p-6 animate-fade-in text-center">
        
      <div className="mb-8">
        <h2 className="text-3xl font-playfair font-bold text-royal-gold mb-2 tracking-wider">
          SESSION CONCLUDED
        </h2>
        <p className="font-cormorant text-royal-ivory italic text-lg opacity-70">
          The Manager awaits your return
        </p>
      </div>

      <div className="w-full max-w-sm bg-royal-wood border-2 border-royal-gold/50 p-8 rounded-lg shadow-2xl relative overflow-hidden mb-10">
         {/* Background accent */}
         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-royal-gold to-transparent"></div>
         
         <div className="flex flex-col gap-6">
            <div>
                <p className="text-royal-gold-dark text-xs uppercase tracking-widest mb-1">Final Balance</p>
                <p className="text-4xl font-playfair font-bold text-royal-ivory">{finalBalance.toLocaleString()}</p>
            </div>

            <div className="h-px bg-royal-gold/20 w-full"></div>

            <div>
                 <p className="text-royal-gold-dark text-xs uppercase tracking-widest mb-1">Session Result</p>
                 <p className={`text-2xl font-bold font-lora ${isProfit ? 'text-green-500' : 'text-royal-red'}`}>
                    {isProfit ? '+' : ''}{totalWon.toLocaleString()}
                 </p>
            </div>
         </div>
      </div>

      <button
        onClick={onRestart}
        className="group relative px-8 py-3 bg-transparent overflow-hidden rounded-md transition-all duration-300 active:scale-95"
      >
        <div className="absolute inset-0 w-full h-full bg-royal-gold border border-white/20 rounded-md shadow-lg group-hover:brightness-110 transition-all"></div>
        <span className="relative z-10 font-playfair text-lg font-bold text-royal-black tracking-wider flex items-center gap-2">
           <RefreshCw size={18} /> REQUEST NEW AUDIENCE
        </span>
      </button>

    </div>
  );
};

export default ResultScreen;