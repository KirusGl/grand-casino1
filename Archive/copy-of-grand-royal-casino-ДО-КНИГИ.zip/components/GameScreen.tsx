import React from 'react';
import { GameType } from '../types';
import { Coins, ArrowLeft } from 'lucide-react';
import RouletteGame from './games/RouletteGame';
import BlackjackGame from './games/BlackjackGame';
import SlotsGame from './games/SlotsGame';
import PokerGame from './games/PokerGame';
import BaccaratGame from './games/BaccaratGame';
import CrapsGame from './games/CrapsGame';
import VideoPokerGame from './games/VideoPokerGame';
import KenoGame from './games/KenoGame';
import RocketGame from './games/RocketGame';
import MinesGame from './games/MinesGame';
import DurakGame from './games/DurakGame';

interface GameScreenProps {
  gameType: GameType;
  balance: number;
  onUpdateBalance: (delta: number) => void;
  onBackToLobby: () => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ gameType, balance, onUpdateBalance, onBackToLobby }) => {
  
  const renderGame = () => {
    const props = {
      balance,
      onUpdateBalance,
    };

    switch (gameType) {
      case GameType.ROULETTE: return <RouletteGame {...props} />;
      case GameType.BLACKJACK: return <BlackjackGame {...props} />;
      case GameType.SLOTS: return <SlotsGame {...props} />;
      case GameType.POKER: return <PokerGame {...props} />;
      case GameType.BACCARAT: return <BaccaratGame {...props} />;
      case GameType.CRAPS: return <CrapsGame {...props} />;
      case GameType.VIDEO_POKER: return <VideoPokerGame {...props} />;
      case GameType.KENO: return <KenoGame {...props} />;
      case GameType.ROCKET: return <RocketGame {...props} />;
      case GameType.MINES: return <MinesGame {...props} />;
      case GameType.DURAK: return <DurakGame {...props} />;
      default: return <div>Game Under Construction</div>;
    }
  };

  return (
    // Apply bg-royal-bg and bg-felt-pattern on the root to match LobbyScreen perfectly
    <div className="flex flex-col h-screen bg-royal-bg bg-felt-pattern text-royal-ivory overflow-hidden relative">
      {/* Top Bar */}
      <div className="flex justify-between items-center p-3 bg-royal-wood border-b-2 border-royal-gold shadow-md z-30 relative">
        <button onClick={onBackToLobby} className="flex items-center gap-1 p-2 rounded hover:bg-white/10 text-royal-gold transition-colors">
            <ArrowLeft size={20} />
            <span className="font-cormorant font-bold uppercase text-xs">Lobby</span>
        </button>
        
        <div className="flex items-center gap-2 bg-royal-black/50 px-3 py-1 rounded-full border border-royal-gold/30">
          <Coins className="text-royal-gold" size={16} />
          <span className="font-lora font-bold text-lg">{balance.toLocaleString()}</span>
        </div>
      </div>

      {/* Game Content - Removed inner bg-felt-pattern to prevent double texture overlay issues */}
      <div className="flex-1 overflow-hidden relative">
        {renderGame()}
      </div>
    </div>
  );
};

export default GameScreen;