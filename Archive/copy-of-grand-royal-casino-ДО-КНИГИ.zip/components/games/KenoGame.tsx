import React, { useState } from 'react';
import { CHIP_VALUES } from '../../constants';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const KenoGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [selected, setSelected] = useState<number[]>([]);
    const [drawn, setDrawn] = useState<number[]>([]);
    const [playing, setPlaying] = useState(false);
    const [bet, setBet] = useState(10);
    const [customBetInput, setCustomBetInput] = useState('');
    const [message, setMessage] = useState("Pick up to 10 numbers");

    const handleCustomBetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = parseInt(e.target.value);
        setCustomBetInput(e.target.value);
        if (!isNaN(val) && val > 0) setBet(val);
    };

    const toggleNum = (n: number) => {
        if (playing) return;
        if (selected.includes(n)) setSelected(selected.filter(x => x !== n));
        else if (selected.length < 10) setSelected([...selected, n]);
    };

    const play = () => {
        if (selected.length === 0) { setMessage("Pick numbers first"); return; }
        if (balance < bet) { setMessage("Low Balance"); return; }
        onUpdateBalance(-bet);
        setPlaying(true);
        setDrawn([]);
        setMessage("Drawing...");

        const drawSequence: number[] = [];
        const pool = Array.from({length: 80}, (_, i) => i + 1);
        
        for(let i=0; i<20; i++) {
            const idx = Math.floor(Math.random() * pool.length);
            drawSequence.push(pool.splice(idx, 1)[0]);
        }

        let i = 0;
        const interval = setInterval(() => {
            setDrawn(prev => [...prev, drawSequence[i]]);
            i++;
            if (i >= 20) {
                clearInterval(interval);
                finish(drawSequence);
            }
        }, 100);
    };

    const finish = (finalDrawn: number[]) => {
        const matches = selected.filter(s => finalDrawn.includes(s)).length;
        let mult = 0;
        if (matches >= 3) mult = matches;
        if (matches >= 5) mult = matches * 2;
        if (matches >= 8) mult = matches * 10;
        
        const win = bet * mult;
        setPlaying(false);
        if (win > 0) {
            onUpdateBalance(win);
            setMessage(`Matched ${matches}! Won ${win}`);
        } else {
            setMessage(`Matched ${matches}. Try again.`);
        }
    };

    return (
        <div className="flex flex-col h-full items-center p-2">
            <div className="text-royal-gold font-playfair mb-2">{message}</div>
            
            <div className="grid grid-cols-10 gap-1 w-full max-w-md mb-4">
                {Array.from({length: 80}, (_, i) => i + 1).map(n => {
                    const isSelected = selected.includes(n);
                    const isDrawn = drawn.includes(n);
                    const isHit = isSelected && isDrawn;
                    
                    return (
                        <button 
                            key={n} 
                            onClick={() => toggleNum(n)}
                            disabled={playing}
                            className={`
                                h-6 md:h-8 w-full text-[10px] md:text-xs font-bold rounded flex items-center justify-center transition-colors
                                ${isHit ? 'bg-royal-gold text-black animate-pulse' : 
                                  isDrawn ? 'bg-royal-red/50 text-white' : 
                                  isSelected ? 'bg-royal-green text-white border border-white' : 
                                  'bg-royal-wood border border-royal-gold/20 text-royal-ivory'}
                            `}
                        >
                            {n}
                        </button>
                    );
                })}
            </div>

            <div className="w-full max-w-md bg-royal-wood/90 p-3 rounded flex justify-between items-center border border-royal-gold/30 gap-2">
                 <div className="flex gap-2 items-center">
                      <button onClick={() => {setBet(Math.max(10, bet-10)); setCustomBetInput('');}} className="px-2 bg-royal-red rounded text-white">-</button>
                      <input 
                            type="number" 
                            value={customBetInput || bet} 
                            onChange={handleCustomBetChange}
                            className="w-16 h-8 bg-black/50 border border-royal-gold text-white text-center rounded text-sm"
                        />
                      <button onClick={() => {setBet(bet+10); setCustomBetInput('');}} className="px-2 bg-royal-green rounded text-white">+</button>
                 </div>
                 <div className="text-xs text-royal-gold">Pick: {selected.length}</div>
                 <button onClick={play} disabled={playing || selected.length === 0} className="px-6 py-2 bg-royal-gold text-black font-bold rounded disabled:opacity-50">PLAY</button>
            </div>
        </div>
    );
};

export default KenoGame;