import React, { useState, useCallback, useEffect } from 'react';
import { WHEEL_NUMBERS, RED_NUMBERS, MULTIPLIERS, CHIP_VALUES } from '../../constants';
import { BetType } from '../../types';
import RouletteWheel from '../RouletteWheel';
import { XCircle, RotateCw } from 'lucide-react';

interface RouletteGameProps {
  balance: number;
  onUpdateBalance: (delta: number) => void;
}

const RouletteGame: React.FC<RouletteGameProps> = ({ balance, onUpdateBalance }) => {
  const [currentBetType, setCurrentBetType] = useState<BetType | null>(null);
  const [currentBetAmount, setCurrentBetAmount] = useState<number>(0);
  const [selectedChip, setSelectedChip] = useState<number>(10);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [message, setMessage] = useState("Place your bets");

  // ... Logic (Spin, Bet, Clear) is same as before, preserving game rules ...
  const handlePlaceBet = (type: BetType) => {
    if (isSpinning || balance < selectedChip) return;
    if (currentBetType !== type && currentBetAmount > 0) onUpdateBalance(currentBetAmount);
    onUpdateBalance(-selectedChip);
    setCurrentBetAmount(prev => prev + selectedChip);
    setCurrentBetType(type);
    setMessage(`${type}: $${selectedChip}`);
  };

  const spinWheel = () => {
    if (isSpinning || currentBetAmount === 0) return;
    setIsSpinning(true);
    const randomIndex = Math.floor(Math.random() * WHEEL_NUMBERS.length);
    const winningNumber = WHEEL_NUMBERS[randomIndex];
    const sectorAngle = 360 / 37;
    const targetRotation = 360 * 5 - (randomIndex * sectorAngle); 
    const nextRotation = rotation + targetRotation + ((Math.random() * 8) - 4);
    setRotation(nextRotation);

    setTimeout(() => {
        setIsSpinning(false);
        const isRed = RED_NUMBERS.includes(winningNumber);
        const isZero = winningNumber === 0;
        let won = false;
        if (currentBetType === 'RED' && isRed) won = true;
        if (currentBetType === 'BLACK' && !isRed && !isZero) won = true;
        if (currentBetType === 'GREEN' && isZero) won = true;
        
        if (won) {
            const mult = currentBetType === 'GREEN' ? MULTIPLIERS.GREEN : 2;
            const win = currentBetAmount * mult;
            onUpdateBalance(win);
            setMessage(`WIN ${winningNumber}! +${win}`);
        } else {
            setMessage(`LOSE ${winningNumber}`);
        }
        setCurrentBetAmount(0);
        setCurrentBetType(null);
    }, 4500);
  };

  return (
    // ADAPTIV: Full viewport container with no scroll
    <div className="flex flex-col h-full w-full bg-royal-bg overflow-hidden relative">
      
      {/* 1. Wheel Section: Grows to fill space, centers content */}
      <div className="flex-1 flex items-center justify-center p-4 min-h-0 w-full relative">
         {/* Container size limited by screen width OR height to keep wheel on screen */}
         {/* using container queries concept via sizing */}
         <div className="relative w-[min(85vw,45vh)] aspect-square max-w-[400px]">
            <div style={{containerType: 'size'}} className="w-full h-full">
                <RouletteWheel rotation={rotation} isSpinning={isSpinning} />
            </div>
            
            {/* Overlay Message */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-40">
                <span className="bg-black/70 px-4 py-1 rounded-full border border-royal-gold/50 text-royal-gold text-sm whitespace-nowrap backdrop-blur-sm shadow-lg">
                    {message}
                </span>
            </div>
         </div>
      </div>

      {/* 2. Controls Section: Fixed at bottom with safe area */}
      <div className="w-full bg-royal-wood/90 border-t border-royal-gold/30 p-[clamp(0.75rem,2vw,1.5rem)] pb-safe z-20 backdrop-blur-md">
         <div className="max-w-md mx-auto w-full flex flex-col gap-[1.5vh]">
            
            {/* Chips Row */}
            <div className="flex justify-center gap-[3vw] md:gap-4">
               {CHIP_VALUES.map(val => (
                   <button 
                     key={val} 
                     onClick={() => setSelectedChip(val)}
                     className={`rounded-full shadow-lg border-2 transition-transform active:scale-95 flex items-center justify-center
                     w-[12vw] h-[12vw] max-w-[50px] max-h-[50px]
                     ${selectedChip === val ? 'bg-royal-gold text-black border-white scale-110' : 'bg-gray-800 text-royal-gold border-gray-600'}
                     `}
                   >
                     <span className="text-[clamp(0.6rem,2.5vw,0.9rem)] font-bold">{val}</span>
                   </button>
               ))}
            </div>

            {/* Betting Grid */}
            <div className="grid grid-cols-4 gap-2 h-[8vh] min-h-[50px] max-h-[70px]">
                 <button 
                    onClick={() => handlePlaceBet('GREEN')} 
                    className={`col-span-1 rounded-l-lg border border-white/10 font-black text-white ${currentBetType === 'GREEN' ? 'bg-green-600 ring-2 ring-white' : 'bg-green-900'}`}
                 >0</button>
                 <button 
                    onClick={() => handlePlaceBet('RED')} 
                    className={`col-span-1 border border-white/10 font-bold text-white flex items-center justify-center ${currentBetType === 'RED' ? 'bg-red-600 ring-2 ring-white' : 'bg-red-900'}`}
                 >
                    <div className="w-4 h-4 bg-red-500 rotate-45 border border-white/20"></div>
                 </button>
                 <button 
                    onClick={() => handlePlaceBet('BLACK')} 
                    className={`col-span-1 border border-white/10 font-bold text-white flex items-center justify-center ${currentBetType === 'BLACK' ? 'bg-gray-700 ring-2 ring-white' : 'bg-black'}`}
                 >
                     <div className="w-4 h-4 bg-black rotate-45 border border-white/40"></div>
                 </button>
                 
                 {/* Action Button */}
                 <button 
                    onClick={spinWheel} 
                    disabled={isSpinning}
                    className="col-span-1 bg-gradient-to-br from-royal-gold to-yellow-600 rounded-r-lg text-black font-black flex items-center justify-center shadow-gold-glow disabled:opacity-50"
                 >
                    <RotateCw size={20} />
                 </button>
            </div>
         </div>
      </div>
    </div>
  );
};

export default RouletteGame;