import React, { useState, useEffect } from 'react';
import { createDeck, Card, evaluatePokerHand } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';
import { CHIP_VALUES } from '../../constants';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const PokerGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [deck, setDeck] = useState<Card[]>([]);
    const [playerHand, setPlayerHand] = useState<Card[]>([]);
    const [dealerHand, setDealerHand] = useState<Card[]>([]);
    const [gameState, setGameState] = useState<'ANTE' | 'DECISION' | 'RESULT'>('ANTE');
    const [ante, setAnte] = useState(0);
    const [customBetInput, setCustomBetInput] = useState('');
    const [message, setMessage] = useState("Place Ante");

    useEffect(() => setDeck(createDeck()), []);

    const placeAnte = (amount: number) => {
        if (balance < amount) return;
        onUpdateBalance(-amount);
        setAnte(prev => prev + amount);
    };

    const setCustomAnte = () => {
        const val = parseInt(customBetInput);
        if (!isNaN(val) && val > 0 && balance >= val) {
            onUpdateBalance(-val);
            setAnte(prev => prev + val);
            setCustomBetInput('');
        }
    };

    const deal = () => {
        if (ante === 0) return;
        let d = [...deck];
        if (d.length < 10) d = createDeck();
        const p = d.splice(0, 5);
        const dealer = d.splice(0, 5);
        setDeck(d);
        setPlayerHand(p);
        setDealerHand(dealer);
        setGameState('DECISION');
        setMessage("Call (2x Ante) or Fold?");
    };

    const fold = () => {
        setGameState('RESULT');
        setMessage("Folded. House Wins.");
        setAnte(0);
    };

    const call = () => {
        const callAmount = ante * 2;
        if (balance < callAmount) {
            setMessage("Insufficient funds to Call");
            return;
        }
        onUpdateBalance(-callAmount);
        
        setGameState('RESULT');
        const pEval = evaluatePokerHand(playerHand);
        const dEval = evaluatePokerHand(dealerHand);
        
        let win = false;
        if (pEval.rank > dEval.rank) win = true;
        else if (pEval.rank === dEval.rank) win = true; 

        if (win) {
            const totalWin = (ante * 2) + (callAmount * 2); 
            onUpdateBalance(totalWin);
            setMessage(`You Win! ${pEval.name}`);
        } else {
            setMessage(`House Wins with ${dEval.name}`);
        }
        setAnte(0);
    };

    const reset = () => {
        setPlayerHand([]);
        setDealerHand([]);
        setGameState('ANTE');
        setMessage("Place Ante");
    };

    return (
        <div className="flex flex-col h-full p-4 items-center justify-between">
            <div className="text-royal-gold font-cormorant text-xl">{message}</div>
            
            <div className="flex flex-col items-center">
                 <div className="text-xs text-royal-gold/50 mb-1">Dealer</div>
                 <div className="flex -space-x-4 scale-90">
                    {gameState === 'ANTE' ? <div className="h-24 w-full"></div> : 
                     dealerHand.map((c, i) => <PlayingCard key={i} card={c} hidden={gameState === 'DECISION' && i > 0} />)}
                 </div>
            </div>

            <div className="flex flex-col items-center">
                 <div className="flex -space-x-4">
                    {playerHand.map((c, i) => <PlayingCard key={i} card={c} />)}
                 </div>
                 {gameState !== 'ANTE' && <div className="text-xs text-royal-gold mt-1">{evaluatePokerHand(playerHand).name}</div>}
            </div>

            <div className="w-full max-w-md bg-royal-wood/90 border border-royal-gold/30 rounded p-3">
                 {gameState === 'ANTE' ? (
                     <div className="flex flex-col gap-2">
                        <div className="flex justify-center gap-2 flex-wrap items-center">
                             {CHIP_VALUES.map(v => <button key={v} onClick={() => placeAnte(v)} className="w-10 h-10 rounded-full bg-royal-gold border-2 border-white text-black font-bold text-xs">{v}</button>)}
                             <div className="flex items-center gap-1">
                                <input 
                                    type="number" 
                                    placeholder="Add"
                                    value={customBetInput}
                                    onChange={(e) => setCustomBetInput(e.target.value)}
                                    className="w-16 h-10 rounded bg-black/50 border border-royal-gold text-white text-center text-xs"
                                />
                                <button onClick={setCustomAnte} className="h-10 px-2 bg-royal-gold text-black font-bold text-xs rounded">ADD</button>
                            </div>
                        </div>
                        <div className="flex justify-between items-center px-4">
                            <span className="text-royal-ivory">Ante: {ante}</span>
                            <button onClick={deal} disabled={ante === 0} className="px-6 py-2 bg-royal-green text-white font-bold rounded">DEAL</button>
                        </div>
                     </div>
                 ) : gameState === 'DECISION' ? (
                     <div className="flex justify-center gap-4">
                         <button onClick={fold} className="px-6 py-2 bg-royal-red text-white font-bold rounded">FOLD</button>
                         <button onClick={call} className="px-6 py-2 bg-royal-gold text-black font-bold rounded">CALL ({ante * 2})</button>
                     </div>
                 ) : (
                     <button onClick={reset} className="w-full py-2 bg-royal-gold text-black font-bold rounded">NEW HAND</button>
                 )}
            </div>
        </div>
    );
};

export default PokerGame;