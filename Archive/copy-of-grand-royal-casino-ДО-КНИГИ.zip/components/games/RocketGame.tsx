import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Rocket, AlertTriangle } from 'lucide-react';
import { CHIP_VALUES } from '../../constants';

interface Props {
  balance: number;
  onUpdateBalance: (delta: number) => void;
}

type GameState = 'IDLE' | 'COUNTDOWN' | 'FLYING' | 'CRASHED' | 'CASHED_OUT';

const RocketGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
  const [status, setStatus] = useState<GameState>('IDLE');
  const [multiplier, setMultiplier] = useState(1);
  const [bet, setBet] = useState(10);
  const [customBetInput, setCustomBetInput] = useState('');
  const [crashPoint, setCrashPoint] = useState(0);
  const [countDown, setCountDown] = useState(3);

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(0);
  const startTimeRef = useRef<number>(0);

  // ADAPTIV: Handle canvas resize dynamically
  const updateCanvasSize = useCallback(() => {
    if (containerRef.current && canvasRef.current) {
      const { width, height } = containerRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      
      // Set physical pixels
      canvasRef.current.width = width * dpr;
      canvasRef.current.height = height * dpr;
      
      // Scale context
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) ctx.scale(dpr, dpr);
      
      // Set CSS size
      canvasRef.current.style.width = `${width}px`;
      canvasRef.current.style.height = `${height}px`;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('resize', updateCanvasSize);
    updateCanvasSize();
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, [updateCanvasSize]);

  // ... Betting Logic ...
  const handleCustomBetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setCustomBetInput(e.target.value);
    if (!isNaN(val) && val > 0) setBet(val);
  };

  const placeBet = () => {
    if (balance < bet || bet <= 0) return;
    onUpdateBalance(-bet);
    setCrashPoint((Math.random() * 5) + 1.1); // Simplified logic
    setMultiplier(1);
    setCountDown(3);
    setStatus('COUNTDOWN');
  };

  const cashOut = () => {
    if (status !== 'FLYING') return;
    cancelAnimationFrame(requestRef.current);
    const win = Math.floor(bet * multiplier);
    onUpdateBalance(win);
    setStatus('CASHED_OUT');
  };

  const reset = () => {
      setStatus('IDLE');
      setMultiplier(1);
      // Clear canvas
      if (canvasRef.current && containerRef.current) {
          const ctx = canvasRef.current.getContext('2d');
          const { width, height } = containerRef.current.getBoundingClientRect();
          ctx?.clearRect(0, 0, width, height);
      }
  };

  // ... Animation Loop ...
  useEffect(() => {
    if (status === 'COUNTDOWN') {
      if (countDown > 0) {
        const t = setTimeout(() => setCountDown(c => c - 1), 1000);
        return () => clearTimeout(t);
      } else {
        setStatus('FLYING');
        startTimeRef.current = performance.now();
        startAnimation();
      }
    }
  }, [status, countDown]);

  const startAnimation = () => {
    const animate = (time: number) => {
      const elapsed = (time - startTimeRef.current) / 1000;
      const nextMult = 1 + Math.pow(elapsed, 1.8) * 0.35;

      if (nextMult >= crashPoint) {
        setMultiplier(crashPoint);
        setStatus('CRASHED');
        cancelAnimationFrame(requestRef.current);
        return;
      }

      setMultiplier(nextMult);
      drawScene(nextMult, elapsed);
      requestRef.current = requestAnimationFrame(animate);
    };
    requestRef.current = requestAnimationFrame(animate);
  };

  const drawScene = (currentMult: number, elapsed: number) => {
    const canvas = canvasRef.current;
    if (!canvas || !containerRef.current) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Get current container dimensions
    const { width: w, height: h } = containerRef.current.getBoundingClientRect();
    ctx.clearRect(0, 0, w, h);

    // ADAPTIV: Boundary Protection
    // Rocket moves from 0 to width, bottom to top
    // Clamp values to ensure it stays within 10% padding
    const paddingX = w * 0.1;
    const paddingY = h * 0.15;
    
    // Calculate raw position
    const rawX = elapsed * (w * 0.15); // Speed relative to width
    const rawY = (currentMult - 1) * (h * 0.6); // Height scaling

    // CLAMP: Apply safety limits
    const x = Math.min(w - paddingX, rawX);
    const y = h - Math.min(h - paddingY, rawY);

    // Draw Grid
    ctx.strokeStyle = '#222';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < w; i += w/10) { ctx.moveTo(i, 0); ctx.lineTo(i, h); }
    for (let i = 0; i < h; i += h/5) { ctx.moveTo(0, i); ctx.lineTo(w, i); }
    ctx.stroke();

    // Draw Trajectory
    const gradient = ctx.createLinearGradient(x, y, 0, h);
    gradient.addColorStop(0, '#d4af37');
    gradient.addColorStop(1, 'transparent');

    ctx.beginPath();
    ctx.moveTo(0, h);
    ctx.quadraticCurveTo(x / 2, h, x, y);
    ctx.strokeStyle = gradient;
    ctx.lineWidth = Math.max(2, w * 0.005); // Adaptive line width
    ctx.lineCap = 'round';
    ctx.stroke();

    // Draw Rocket (Scaled by screen width)
    const rocketSize = Math.max(6, w * 0.015);
    
    // Flame
    ctx.beginPath();
    ctx.moveTo(x, y + rocketSize);
    ctx.lineTo(x - rocketSize * 1.5, y + rocketSize * 2);
    ctx.lineTo(x - rocketSize * 0.5, y + rocketSize * 1.5);
    ctx.fillStyle = '#ff4500';
    ctx.fill();

    // Body
    ctx.beginPath();
    ctx.arc(x, y, rocketSize, 0, Math.PI * 2);
    ctx.fillStyle = status === 'CRASHED' ? '#8B0000' : '#f8f3e6';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#d4af37';
    ctx.fill();
    ctx.shadowBlur = 0;
  };

  return (
    // ADAPTIV: Root container with overflow hidden and full height
    <div className="flex flex-col h-full w-full overflow-hidden bg-royal-bg text-royal-ivory">
      
      {/* Game Area: Flex-1 to take available space */}
      <div ref={containerRef} className="flex-1 relative flex items-center justify-center overflow-hidden w-full">
        <canvas ref={canvasRef} className="absolute inset-0 block touch-none" />
        
        {/* UI Overlay */}
        <div className="z-10 text-center pointer-events-none">
            {status === 'COUNTDOWN' && (
               <div className="font-black text-royal-gold animate-pulse text-[clamp(4rem,15vw,8rem)]">{countDown}</div>
            )}
            {(status === 'FLYING' || status === 'CASHED_OUT') && (
               <div className={`font-black tracking-tighter text-[clamp(4rem,15vw,8rem)] leading-none ${
                 status === 'CASHED_OUT' ? 'text-green-500' : 'text-royal-gold'
               }`}>
                 {multiplier.toFixed(2)}x
               </div>
            )}
             {status === 'CRASHED' && (
               <div className="flex flex-col items-center animate-bounce">
                  <AlertTriangle className="text-royal-red w-[15vw] h-[15vw] max-w-[80px]" />
                  <div className="font-black text-royal-red text-[clamp(2rem,8vw,4rem)]">CRASHED</div>
                  <div className="text-royal-gold text-[clamp(1rem,4vw,1.5rem)]">@{multiplier.toFixed(2)}x</div>
               </div>
            )}
        </div>
      </div>

      {/* Controls: Safe area padding */}
      <div className="w-full bg-royal-wood/90 border-t border-royal-gold/30 p-[clamp(1rem,3vw,1.5rem)] pb-safe z-20">
         <div className="max-w-md mx-auto w-full">
            {status === 'IDLE' || status === 'CRASHED' || status === 'CASHED_OUT' ? (
                <>
                  <div className="grid grid-cols-4 gap-2 mb-4 w-full">
                      {CHIP_VALUES.map(v => (
                          <button key={v} onClick={() => {setBet(v); setCustomBetInput('')}} className={`py-2 rounded border transition-colors text-[clamp(0.7rem,2.5vw,1rem)] font-bold ${bet === v && customBetInput === '' ? 'bg-royal-gold text-black border-royal-ivory' : 'border-royal-gold/50 text-royal-gold'}`}>
                              {v}
                          </button>
                      ))}
                  </div>
                  <div className="flex gap-2 mb-4">
                      <input 
                         type="number" 
                         value={customBetInput} 
                         onChange={handleCustomBetChange} 
                         placeholder="Custom"
                         className="flex-1 bg-black/50 border border-royal-gold rounded px-3 text-white text-center"
                      />
                  </div>
                  <div className="flex gap-2">
                     <button onClick={placeBet} className="flex-1 py-[2vh] bg-royal-gold text-black font-black text-[clamp(1rem,4vw,1.25rem)] rounded shadow-gold-glow">
                         LAUNCH
                     </button>
                     {(status === 'CRASHED' || status === 'CASHED_OUT') && (
                        <button onClick={reset} className="px-4 border border-royal-gold/30 rounded text-royal-gold">R</button>
                     )}
                  </div>
                </>
            ) : (
                <button onClick={cashOut} className="w-full py-[2.5vh] bg-royal-green text-white font-black text-[clamp(1.2rem,5vw,2rem)] rounded shadow-lg">
                    CASH OUT {(bet * multiplier).toFixed(0)}
                </button>
            )}
         </div>
      </div>
    </div>
  );
};

export default RocketGame;