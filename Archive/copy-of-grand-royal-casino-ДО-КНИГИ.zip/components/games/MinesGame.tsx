import React, { useState } from 'react';
import { Diamond, Bomb } from 'lucide-react';
import { CHIP_VALUES } from '../../constants';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const MinesGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [gameState, setGameState] = useState<'BETTING' | 'PLAYING' | 'GAMEOVER' | 'VICTORY'>('BETTING');
    const [bet, setBet] = useState(10);
    const [minesCount, setMinesCount] = useState(3);
    const [revealed, setRevealed] = useState<boolean[]>(Array(25).fill(false));
    const [mineLocations, setMineLocations] = useState<number[]>([]);
    const [gemsFound, setGemsFound] = useState(0);

    // ... Logic (Start, Click, Cashout) remains same ...
    const startGame = () => {
        if (balance < bet) return;
        onUpdateBalance(-bet);
        const mines: number[] = [];
        while(mines.length < minesCount) {
            const r = Math.floor(Math.random() * 25);
            if(!mines.includes(r)) mines.push(r);
        }
        setMineLocations(mines);
        setRevealed(Array(25).fill(false));
        setGemsFound(0);
        setGameState('PLAYING');
    };

    const handleTileClick = (index: number) => {
        if (gameState !== 'PLAYING' || revealed[index]) return;
        const newRevealed = [...revealed];
        newRevealed[index] = true;
        setRevealed(newRevealed);
        if (mineLocations.includes(index)) {
            setGameState('GAMEOVER');
            setRevealed(Array(25).fill(true));
        } else {
            const found = gemsFound + 1;
            setGemsFound(found);
            if (found === 25 - minesCount) cashOut(found);
        }
    };

    const cashOut = (f?: number) => {
        if (gameState !== 'PLAYING') return;
        // Calc simplified multiplier
        let m = 1.0;
        const found = f !== undefined ? f : gemsFound;
        for(let i=0; i<found; i++) m = m * (25 - i) / (25 - minesCount - i);
        
        onUpdateBalance(Math.floor(bet * m));
        setGameState('VICTORY');
        setRevealed(Array(25).fill(true));
    };

    return (
        // ADAPTIV: Container max-width and hidden overflow
        <div className="flex flex-col h-full w-full bg-royal-bg overflow-hidden items-center justify-between">
            
            {/* Header */}
            <div className="w-full flex justify-between items-center p-[4vw] md:p-6 pb-2">
                <span className="text-royal-gold font-playfair text-[clamp(1.5rem,5vw,2.5rem)]">Royal Mines</span>
                <div className={`font-mono font-bold text-[clamp(1rem,4vw,1.5rem)] ${gameState === 'GAMEOVER' ? 'text-red-500' : 'text-royal-green'}`}>
                    {gameState === 'PLAYING' ? `Hit: ${gemsFound}` : gameState === 'VICTORY' ? 'WON' : gameState === 'GAMEOVER' ? 'LOST' : ''}
                </div>
            </div>

            {/* Grid Container: Always square, never wider than screen, never taller than available space */}
            <div className="flex-1 w-full flex items-center justify-center p-4">
                <div className="w-full max-w-[min(90vw,400px)] aspect-square grid grid-cols-5 gap-[2vw] md:gap-3">
                    {Array.from({length: 25}).map((_, i) => {
                        const isMine = mineLocations.includes(i);
                        const isRevealed = revealed[i];
                        return (
                            <button
                                key={i}
                                onClick={() => handleTileClick(i)}
                                disabled={gameState !== 'PLAYING' || isRevealed}
                                className={`
                                    relative w-full h-full rounded-[15%] transition-all duration-200 shadow-lg
                                    ${isRevealed 
                                        ? (isMine ? 'bg-red-900/80 shadow-inner' : 'bg-royal-green/20 border border-royal-green') 
                                        : 'bg-royal-wood hover:bg-royal-wood/80 border border-royal-gold/20 active:scale-95'}
                                `}
                            >
                                <div className="absolute inset-0 flex items-center justify-center">
                                    {isRevealed && isMine && <Bomb className="w-[60%] h-[60%] text-red-500 animate-pulse" />}
                                    {isRevealed && !isMine && <Diamond className="w-[60%] h-[60%] text-cyan-400 animate-bounce" />}
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Controls */}
            <div className="w-full bg-royal-wood/90 border-t border-royal-gold/30 p-[clamp(1rem,3vw,1.5rem)] pb-safe">
                 <div className="max-w-md mx-auto flex flex-col gap-3">
                    {gameState === 'BETTING' || gameState === 'GAMEOVER' || gameState === 'VICTORY' ? (
                        <>
                            <div className="flex justify-between gap-2">
                                <span className="text-royal-ivory text-sm py-2">Mines:</span>
                                {[1, 3, 5, 10].map(m => (
                                    <button key={m} onClick={() => setMinesCount(m)} className={`flex-1 rounded text-xs font-bold ${minesCount === m ? 'bg-royal-gold text-black' : 'bg-black/50 text-royal-gold'}`}>
                                        {m}
                                    </button>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                {CHIP_VALUES.map(v => (
                                    <button key={v} onClick={() => setBet(v)} className={`flex-1 py-2 rounded text-xs font-bold border ${bet === v ? 'bg-royal-gold text-black' : 'border-royal-gold text-royal-gold'}`}>{v}</button>
                                ))}
                            </div>
                            <button onClick={startGame} className="w-full py-3 bg-royal-gold text-black font-bold text-lg rounded shadow-gold-glow uppercase">Start Round</button>
                        </>
                    ) : (
                        <button onClick={() => cashOut()} className="w-full py-4 bg-royal-green text-white font-bold text-xl rounded shadow-lg uppercase">
                            Cash Out
                        </button>
                    )}
                 </div>
            </div>
        </div>
    );
};

export default MinesGame;