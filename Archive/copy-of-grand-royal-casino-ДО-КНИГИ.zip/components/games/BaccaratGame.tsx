import React, { useState } from 'react';
import { createDeck, Card } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';
import { CHIP_VALUES } from '../../constants';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const BaccaratGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [pHand, setPHand] = useState<Card[]>([]);
    const [bHand, setBHand] = useState<Card[]>([]);
    const [betType, setBetType] = useState<'PLAYER' | 'BANKER' | 'TIE' | null>(null);
    const [bet, setBet] = useState(0);
    const [customBetInput, setCustomBetInput] = useState('');
    const [message, setMessage] = useState("Choose Player, Banker, or Tie");

    const getScore = (hand: Card[]) => {
        let score = hand.reduce((acc, c) => {
            if (['10', 'J', 'Q', 'K'].includes(c.rank)) return acc;
            if (c.rank === 'A') return acc + 1;
            return acc + parseInt(c.rank);
        }, 0);
        return score % 10;
    };

    const placeBet = (type: 'PLAYER' | 'BANKER' | 'TIE') => {
        if (bet > 0) return; 
        setBetType(type);
    };

    const addChips = (amount: number) => {
        if (!betType || balance < amount) return;
        onUpdateBalance(-amount);
        setBet(prev => prev + amount);
    };

    const setCustomChips = () => {
        const val = parseInt(customBetInput);
        if (!betType || isNaN(val) || val <= 0 || balance < val) return;
        onUpdateBalance(-val);
        setBet(prev => prev + val);
        setCustomBetInput('');
    };

    const deal = () => {
        if (bet === 0) return;
        const deck = createDeck();
        const p = [deck.pop()!, deck.pop()!];
        const b = [deck.pop()!, deck.pop()!];
        
        let pScore = getScore(p);
        let bScore = getScore(b);
        
        if (pScore < 8 && bScore < 8) {
            if (pScore <= 5) p.push(deck.pop()!);
            if (bScore <= 5) b.push(deck.pop()!); 
        }

        setPHand(p);
        setBHand(b);
        
        const finalP = getScore(p);
        const finalB = getScore(b);
        
        let win = false;
        let payout = 0;

        if (finalP > finalB && betType === 'PLAYER') { win = true; payout = bet * 2; }
        else if (finalB > finalP && betType === 'BANKER') { win = true; payout = Math.floor(bet * 1.95); } // 5% commission
        else if (finalP === finalB && betType === 'TIE') { win = true; payout = bet * 9; }
        else if (finalP === finalB && betType !== 'TIE') { payout = bet; setMessage("Push"); onUpdateBalance(bet); setBet(0); return;} 
        
        if (win) {
            onUpdateBalance(payout);
            setMessage("You Win!");
        } else {
            setMessage("House Wins");
        }
        setBet(0);
        setBetType(null);
    };

    return (
        <div className="flex flex-col h-full p-4 items-center justify-between">
            <div className="text-royal-gold font-cormorant text-xl">{message}</div>
            
            <div className="flex justify-around w-full max-w-md">
                <div className="flex flex-col items-center">
                    <span className="text-royal-gold mb-2">PLAYER ({getScore(pHand)})</span>
                    <div className="flex -space-x-4">
                        {pHand.length === 0 ? <div className="w-16 h-24 border border-white/20 rounded"></div> : pHand.map((c, i) => <PlayingCard key={i} card={c} />)}
                    </div>
                </div>
                <div className="flex flex-col items-center">
                    <span className="text-royal-gold mb-2">BANKER ({getScore(bHand)})</span>
                    <div className="flex -space-x-4">
                        {bHand.length === 0 ? <div className="w-16 h-24 border border-white/20 rounded"></div> : bHand.map((c, i) => <PlayingCard key={i} card={c} />)}
                    </div>
                </div>
            </div>

            <div className="w-full max-w-md">
                <div className="flex justify-center gap-4 mb-4">
                    {['PLAYER', 'TIE', 'BANKER'].map(t => (
                        <button key={t} onClick={() => placeBet(t as any)} className={`px-4 py-8 rounded border-2 w-1/3 transition-all ${betType === t ? 'bg-royal-gold text-black border-white' : 'bg-transparent text-royal-gold border-royal-gold/50'}`}>
                            <div className="font-bold text-xs md:text-sm">{t}</div>
                            {betType === t && <div className="text-xs font-bold mt-1">{bet}</div>}
                        </button>
                    ))}
                </div>
                
                {betType && (
                    <div className="bg-royal-wood/90 p-3 rounded border border-royal-gold/30">
                        <div className="flex justify-center gap-2 mb-2 flex-wrap items-center">
                            {CHIP_VALUES.map(v => <button key={v} onClick={() => addChips(v)} className="w-8 h-8 rounded-full bg-royal-gold text-black font-bold text-xs">{v}</button>)}
                            <div className="flex items-center gap-1">
                                <input 
                                    type="number" 
                                    placeholder="Add"
                                    value={customBetInput}
                                    onChange={(e) => setCustomBetInput(e.target.value)}
                                    className="w-16 h-8 rounded bg-black/50 border border-royal-gold text-white text-center text-xs"
                                />
                                <button onClick={setCustomChips} className="h-8 px-2 bg-royal-gold text-black font-bold text-xs rounded">ADD</button>
                            </div>
                        </div>
                        <button onClick={deal} disabled={bet === 0} className="w-full py-2 bg-royal-green text-white font-bold rounded">DEAL</button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default BaccaratGame;