import React, { useState } from 'react';
import { CHIP_VALUES } from '../../constants';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6 } from 'lucide-react';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const CrapsGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [point, setPoint] = useState<number | null>(null);
    const [bet, setBet] = useState(0);
    const [customBetInput, setCustomBetInput] = useState('');
    const [dice, setDice] = useState([1, 1]);
    const [rolling, setRolling] = useState(false);
    const [message, setMessage] = useState("Bet Pass Line");

    const DiceIcon = [Dice1, Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];

    const addBet = (amount: number) => {
        if (point !== null) return; 
        if (balance < amount) return;
        onUpdateBalance(-amount);
        setBet(prev => prev + amount);
    };

    const setCustomBet = () => {
        const val = parseInt(customBetInput);
        if (point === null && !isNaN(val) && val > 0 && balance >= val) {
            // Reset current bet if any to apply exact new bet (or just add? Let's add for consistency with chips, or set exact?)
            // Usually chips ADD. Let's make input ADD to current bet.
            onUpdateBalance(-val);
            setBet(prev => prev + val);
            setCustomBetInput('');
        }
    };

    const roll = () => {
        if (bet === 0) { setMessage("Place Bet"); return; }
        setRolling(true);
        let count = 0;
        const interval = setInterval(() => {
            setDice([Math.ceil(Math.random() * 6), Math.ceil(Math.random() * 6)]);
            count++;
            if (count > 10) {
                clearInterval(interval);
                finishRoll();
            }
        }, 100);
    };

    const finishRoll = () => {
        setRolling(false);
        const d1 = Math.ceil(Math.random() * 6);
        const d2 = Math.ceil(Math.random() * 6);
        setDice([d1, d2]);
        const total = d1 + d2;
        
        if (point === null) {
            if (total === 7 || total === 11) {
                win(bet * 2);
            } else if (total === 2 || total === 3 || total === 12) {
                lose();
            } else {
                setPoint(total);
                setMessage(`Point is ${total}. Roll ${total} to win!`);
            }
        } else {
            if (total === point) {
                win(bet * 2);
                setPoint(null);
            } else if (total === 7) {
                lose();
                setPoint(null);
            } else {
                setMessage(`Rolled ${total}. Point is ${point}.`);
            }
        }
    };

    const win = (amount: number) => {
        onUpdateBalance(amount);
        setMessage("YOU WIN!");
        setBet(0);
    };

    const lose = () => {
        setMessage("CRAPS! You Lose.");
        setBet(0);
    };

    return (
        <div className="flex flex-col h-full items-center justify-center p-4">
             <div className="text-3xl font-playfair text-royal-gold mb-8">{message}</div>
             
             <div className="flex gap-4 mb-12">
                 <div className="w-24 h-24 bg-royal-ivory rounded-xl flex items-center justify-center text-black shadow-lg">
                    {React.createElement(DiceIcon[dice[0]], { size: 64 })}
                 </div>
                 <div className="w-24 h-24 bg-royal-ivory rounded-xl flex items-center justify-center text-black shadow-lg">
                    {React.createElement(DiceIcon[dice[1]], { size: 64 })}
                 </div>
             </div>

             <div className="bg-royal-wood/90 p-4 rounded-xl border border-royal-gold/50 w-full max-w-sm">
                 <div className="text-center text-royal-ivory mb-2">PASS LINE BET: {bet}</div>
                 
                 {point === null && (
                    <div className="flex justify-center gap-2 mb-4 flex-wrap items-center">
                        {CHIP_VALUES.map(v => <button key={v} onClick={() => addBet(v)} className="w-10 h-10 rounded-full bg-royal-gold font-bold text-black text-xs hover:scale-110 transition">{v}</button>)}
                        <div className="flex items-center gap-1">
                            <input 
                                type="number" 
                                placeholder="Custom"
                                value={customBetInput}
                                onChange={(e) => setCustomBetInput(e.target.value)}
                                className="w-16 h-10 rounded bg-black/50 border border-royal-gold text-white text-center text-xs"
                            />
                            <button onClick={setCustomBet} className="h-10 px-2 bg-royal-gold text-black font-bold text-xs rounded">ADD</button>
                        </div>
                    </div>
                 )}

                 <button onClick={roll} disabled={bet === 0 || rolling} className="w-full py-4 bg-royal-red text-white font-bold text-xl rounded shadow-gold-glow hover:bg-red-700 transition disabled:opacity-50">
                     {rolling ? 'ROLLING...' : 'ROLL DICE'}
                 </button>
             </div>
        </div>
    );
};

export default CrapsGame;