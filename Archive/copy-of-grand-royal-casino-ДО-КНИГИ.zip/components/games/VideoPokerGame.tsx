import React, { useState } from 'react';
import { createDeck, Card, evaluatePokerHand } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const VideoPokerGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [hand, setHand] = useState<Card[]>([]);
    const [held, setHeld] = useState<boolean[]>([false, false, false, false, false]);
    const [deck, setDeck] = useState<Card[]>([]);
    const [phase, setPhase] = useState<'BET' | 'DRAW'>('BET');
    const [bet, setBet] = useState(10);
    const [customBetInput, setCustomBetInput] = useState('');
    const [message, setMessage] = useState("Jacks or Better");

    const handleCustomBetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = parseInt(e.target.value);
        setCustomBetInput(e.target.value);
        if (!isNaN(val) && val > 0) setBet(val);
    };

    const deal = () => {
        if (balance < bet) { setMessage("Insufficient funds"); return; }
        onUpdateBalance(-bet);
        const d = createDeck();
        setHand(d.splice(0, 5));
        setDeck(d);
        setPhase('DRAW');
        setMessage("Hold cards and Draw");
        setHeld([false, false, false, false, false]);
    };

    const toggleHold = (index: number) => {
        if (phase !== 'DRAW') return;
        const newHeld = [...held];
        newHeld[index] = !newHeld[index];
        setHeld(newHeld);
    };

    const draw = () => {
        const newHand = hand.map((c, i) => held[i] ? c : deck.pop()!);
        setHand(newHand);
        const result = evaluatePokerHand(newHand);
        
        const pays: {[key: number]: number} = {
            9: 250, 8: 50, 7: 25, 6: 9, 5: 6, 4: 4, 3: 3, 2: 2, 1: 1, 0: 0
        };
        
        const mult = pays[result.rank] || 0;
        const win = bet * mult;
        
        if (win > 0) {
            onUpdateBalance(win);
            setMessage(`${result.name}! Won ${win}`);
        } else {
            setMessage("Game Over");
        }
        setPhase('BET');
    };

    return (
        <div className="flex flex-col h-full items-center justify-between p-4">
             <div className="text-xl text-royal-gold font-playfair">{message}</div>
             
             <div className="flex justify-center gap-1 md:gap-2 w-full max-w-lg">
                 {hand.length === 0 ? [1,2,3,4,5].map(i => <div key={i} className="w-16 h-24 bg-royal-wood border border-royal-gold/20 rounded"></div>) :
                  hand.map((c, i) => (
                      <div key={i} className="relative cursor-pointer" onClick={() => toggleHold(i)}>
                          <PlayingCard card={c} className={held[i] ? 'ring-2 ring-royal-gold' : ''} />
                          {held[i] && phase === 'DRAW' && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-royal-gold text-black text-[10px] font-bold px-2 rounded">HELD</div>}
                      </div>
                  ))
                 }
             </div>

             <div className="w-full max-w-md bg-royal-wood/90 p-4 rounded border border-royal-gold/30">
                 {phase === 'BET' ? (
                     <div className="flex items-center justify-between">
                         <div className="flex items-center gap-2">
                            <button onClick={() => {setBet(Math.max(10, bet - 10)); setCustomBetInput('');}} className="w-8 h-8 bg-royal-red rounded text-white">-</button>
                            <input 
                                type="number" 
                                value={customBetInput || bet} 
                                onChange={handleCustomBetChange}
                                className="w-16 h-8 bg-black/50 border border-royal-gold text-white text-center rounded text-sm"
                            />
                            <button onClick={() => {setBet(bet + 10); setCustomBetInput('');}} className="w-8 h-8 bg-royal-green rounded text-white">+</button>
                         </div>
                         <button onClick={deal} className="px-6 py-2 bg-royal-gold text-black font-bold rounded">DEAL</button>
                     </div>
                 ) : (
                     <button onClick={draw} className="w-full py-3 bg-royal-gold text-black font-bold rounded shadow-gold-glow">DRAW</button>
                 )}
             </div>
        </div>
    );
};

export default VideoPokerGame;