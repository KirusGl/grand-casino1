import React, { useState, useEffect } from 'react';
import { createDeck, Card, getBlackjackScore } from '../../utils/cardUtils';
import PlayingCard from '../shared/PlayingCard';
import { CHIP_VALUES } from '../../constants';

interface Props {
  balance: number;
  onUpdateBalance: (delta: number) => void;
}

const BlackjackGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [gameState, setGameState] = useState<'BETTING' | 'PLAYING' | 'DEALER_TURN' | 'ENDED'>('BETTING');
  const [bet, setBet] = useState(0);
  const [customBetInput, setCustomBetInput] = useState<string>('');
  const [message, setMessage] = useState("Place your bet");

  useEffect(() => {
    setDeck(createDeck());
  }, []);

  const addBet = (amount: number) => {
    if (balance < amount) return;
    onUpdateBalance(-amount);
    setBet(prev => prev + amount);
  };

  const setCustomBet = () => {
     const val = parseInt(customBetInput);
     if (!isNaN(val) && val > 0 && balance >= val) {
         // Refund current bet if any to "reset" then apply new
         if (bet > 0) onUpdateBalance(bet);
         onUpdateBalance(-val);
         setBet(val);
         setCustomBetInput('');
     }
  };

  const deal = () => {
    if (bet === 0) { setMessage("Bet required"); return; }
    const newDeck = [...deck];
    if (newDeck.length < 10) { setDeck(createDeck()); return; }
    
    const pHand = [newDeck.pop()!, newDeck.pop()!];
    const dHand = [newDeck.pop()!, newDeck.pop()!];
    
    setPlayerHand(pHand);
    setDealerHand(dHand);
    setDeck(newDeck);
    setGameState('PLAYING');
    setMessage("Hit or Stand?");

    if (getBlackjackScore(pHand) === 21) {
       handleEnd(pHand, dHand, true);
    }
  };

  const hit = () => {
    const newDeck = [...deck];
    const card = newDeck.pop()!;
    const newHand = [...playerHand, card];
    setPlayerHand(newHand);
    setDeck(newDeck);
    
    if (getBlackjackScore(newHand) > 21) {
        setGameState('ENDED');
        setMessage("Bust! House Wins.");
        setBet(0);
    }
  };

  const stand = () => {
    setGameState('DEALER_TURN');
    let dHand = [...dealerHand];
    let dDeck = [...deck];
    while (getBlackjackScore(dHand) < 17) {
        dHand.push(dDeck.pop()!);
    }
    setDealerHand(dHand);
    setDeck(dDeck);
    handleEnd(playerHand, dHand, false);
  };

  const handleEnd = (pHand: Card[], dHand: Card[], instantBj: boolean) => {
    const pScore = getBlackjackScore(pHand);
    const dScore = getBlackjackScore(dHand);
    setGameState('ENDED');

    if (pScore > 21) {
        setMessage("Bust!");
        setBet(0);
    } else if (instantBj) {
        const win = Math.floor(bet * 2.5);
        onUpdateBalance(win);
        setMessage("Blackjack! You win!");
        setBet(0);
    } else if (dScore > 21 || pScore > dScore) {
        onUpdateBalance(bet * 2);
        setMessage("You Win!");
        setBet(0);
    } else if (pScore === dScore) {
        onUpdateBalance(bet);
        setMessage("Push");
        setBet(0);
    } else {
        setMessage("House Wins");
        setBet(0);
    }
  };

  const reset = () => {
    setPlayerHand([]);
    setDealerHand([]);
    setGameState('BETTING');
    setMessage("Place your bet");
    if (deck.length < 15) setDeck(createDeck());
  };

  return (
    <div className="flex flex-col h-full p-4 items-center justify-between">
       <div className="text-center text-royal-gold font-cormorant text-xl mb-2">{message}</div>
       
       <div className="flex flex-col items-center gap-2">
          <div className="text-xs text-royal-gold/50 uppercase">Dealer {gameState === 'ENDED' && `(${getBlackjackScore(dealerHand)})`}</div>
          <div className="flex -space-x-4">
             {dealerHand.map((c, i) => <PlayingCard key={i} card={c} hidden={gameState === 'PLAYING' && i === 1} />)}
             {dealerHand.length === 0 && <div className="w-16 h-24 border border-royal-gold/20 rounded"></div>}
          </div>
       </div>

       <div className="flex flex-col items-center gap-2">
          <div className="flex -space-x-8">
             {playerHand.map((c, i) => <PlayingCard key={i} card={c} />)}
          </div>
          <div className="text-xs text-royal-gold/50 uppercase">Player {playerHand.length > 0 && `(${getBlackjackScore(playerHand)})`}</div>
       </div>

       <div className="w-full max-w-sm bg-royal-wood/90 border border-royal-gold/30 rounded-lg p-3">
          {gameState === 'BETTING' ? (
             <div className="flex flex-col gap-2">
                <div className="flex justify-center items-center gap-2 flex-wrap">
                   {CHIP_VALUES.map(val => (
                       <button key={val} onClick={() => addBet(val)} className="w-10 h-10 rounded-full bg-royal-gold border-2 border-white text-black font-bold text-xs hover:scale-110 transition">{val}</button>
                   ))}
                   <div className="flex items-center gap-1">
                     <input 
                        type="number" 
                        placeholder="Custom" 
                        value={customBetInput} 
                        onChange={(e) => setCustomBetInput(e.target.value)}
                        className="w-16 h-10 rounded bg-black/50 border border-royal-gold text-white text-xs text-center p-1"
                     />
                     <button onClick={setCustomBet} className="h-10 px-2 bg-royal-gold text-black font-bold text-xs rounded">SET</button>
                   </div>
                </div>
                <div className="flex items-center justify-between px-4 mt-2">
                    <span className="text-royal-ivory">Bet: {bet}</span>
                    <button onClick={deal} disabled={bet === 0} className="px-6 py-2 bg-royal-green text-white font-playfair font-bold rounded shadow-gold-glow disabled:opacity-50">DEAL</button>
                </div>
             </div>
          ) : gameState === 'PLAYING' ? (
             <div className="flex justify-center gap-4">
                 <button onClick={hit} className="px-6 py-3 bg-royal-gold text-black font-bold rounded shadow-lg">HIT</button>
                 <button onClick={stand} className="px-6 py-3 bg-royal-red text-white font-bold rounded shadow-lg">STAND</button>
             </div>
          ) : (
             <div className="flex justify-center">
                 <button onClick={reset} className="px-8 py-2 bg-royal-gold text-black font-bold rounded shadow-gold-glow">PLAY AGAIN</button>
             </div>
          )}
       </div>
    </div>
  );
};

export default BlackjackGame;