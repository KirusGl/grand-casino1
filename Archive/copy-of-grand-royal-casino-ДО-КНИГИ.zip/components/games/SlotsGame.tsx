import React, { useState } from 'react';
import { CHIP_VALUES } from '../../constants';

interface Props { balance: number; onUpdateBalance: (d: number) => void; }

const SYMBOLS = ['🍒', '🍋', '🔔', '💎', '7️⃣', '👑'];
const PAYOUTS = { '🍒': 2, '🍋': 3, '🔔': 5, '💎': 10, '7️⃣': 20, '👑': 50 };

const SlotsGame: React.FC<Props> = ({ balance, onUpdateBalance }) => {
    const [reels, setReels] = useState(['7️⃣', '7️⃣', '7️⃣']);
    const [spinning, setSpinning] = useState(false);
    const [bet, setBet] = useState(10);
    const [customBetInput, setCustomBetInput] = useState('');
    const [message, setMessage] = useState("SPIN TO WIN");

    const handleCustomBetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = parseInt(e.target.value);
        setCustomBetInput(e.target.value);
        if (!isNaN(val) && val > 0) setBet(val);
    };

    const spin = () => {
        if (balance < bet) { setMessage("Low Balance"); return; }
        onUpdateBalance(-bet);
        setSpinning(true);
        setMessage("Spinning...");

        let interval = setInterval(() => {
            setReels([
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]
            ]);
        }, 100);

        setTimeout(() => {
            clearInterval(interval);
            const finalReels = [
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
                SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]
            ];
            
            setReels(finalReels);
            setSpinning(false);
            
            if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
                const win = bet * PAYOUTS[finalReels[0] as keyof typeof PAYOUTS];
                onUpdateBalance(win);
                setMessage(`JACKPOT! Won ${win}`);
            } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2] || finalReels[0] === finalReels[2]) {
                const win = Math.floor(bet * 1.5);
                onUpdateBalance(win);
                setMessage(`Small Win: ${win}`);
            } else {
                setMessage("Try Again");
            }
        }, 2000);
    };

    return (
        <div className="flex flex-col h-full items-center justify-center p-4">
            <div className="bg-royal-wood p-6 rounded-xl border-4 border-royal-gold shadow-2xl relative">
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-royal-gold text-black px-4 py-1 rounded font-bold font-playfair tracking-widest uppercase text-sm border-2 border-white shadow-lg whitespace-nowrap">
                   {message}
                </div>
                
                <div className="flex gap-2 mb-6 bg-black p-4 rounded-lg border border-royal-gold/50 shadow-inner">
                    {reels.map((s, i) => (
                        <div key={i} className="w-20 h-28 bg-white rounded flex items-center justify-center text-4xl border-2 border-gray-300 shadow-inner">
                            {s}
                        </div>
                    ))}
                </div>
                
                <div className="flex items-center justify-between bg-black/30 p-2 rounded gap-2">
                    <div className="flex gap-1 items-center">
                        <button onClick={() => {setBet(Math.max(10, bet - 10)); setCustomBetInput('');}} className="w-8 h-8 bg-royal-red text-white rounded">-</button>
                        <input 
                            type="number" 
                            value={customBetInput || bet} 
                            onChange={handleCustomBetChange}
                            className="w-16 h-8 bg-black/50 border border-royal-gold text-white text-center rounded text-sm"
                        />
                        <button onClick={() => {setBet(bet + 10); setCustomBetInput('');}} className="w-8 h-8 bg-royal-green text-white rounded">+</button>
                    </div>
                    <button onClick={spin} disabled={spinning} className="px-6 py-2 bg-royal-gold text-black font-bold rounded shadow-gold-glow hover:bg-white transition-colors disabled:opacity-50">
                        SPIN
                    </button>
                </div>
            </div>
            
            <div className="mt-8 text-center text-royal-gold/50 text-xs font-lora">
                <p>MATCH 3 TO WIN BIG</p>
                <p>👑 = 50x • 7️⃣ = 20x • 💎 = 10x</p>
            </div>
        </div>
    );
};

export default SlotsGame;