import React from 'react';
import { DEVELOPER_INFO } from '../constants';
import { Play, Shield } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
  userName: string;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart, userName }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen w-full bg-royal-bg bg-felt-pattern relative p-6 text-center animate-fade-in">
      
      {/* Decorative Border */}
      <div className="absolute inset-4 border-2 border-royal-gold opacity-20 pointer-events-none rounded-lg" />
      <div className="absolute inset-5 border border-royal-gold opacity-10 pointer-events-none rounded-lg" />

      {/* Logo Area */}
      <div className="mb-12 relative z-10">
        <div className="flex justify-center mb-4 text-royal-gold">
          <Shield size={48} strokeWidth={1} />
        </div>
        <h1 className="text-5xl md:text-6xl font-playfair font-black tracking-wider uppercase mb-2 gold-text-gradient drop-shadow-md">
          Grand<br />Royal
        </h1>
        <div className="h-px w-32 bg-royal-gold mx-auto mb-3 opacity-50"></div>
        <p className="text-royal-gold-dark font-cormorant text-lg italic tracking-widest">
          EST. 1897
        </p>
      </div>

      {/* Greeting */}
      <p className="font-lora text-royal-ivory mb-8 opacity-80 max-w-xs text-sm">
        Welcome, {userName}.<br/>Private Membership Required.
      </p>

      {/* Main Action */}
      <button
        onClick={onStart}
        className="group relative px-8 py-4 bg-transparent overflow-hidden rounded-md transition-all duration-300 transform hover:scale-105 active:scale-95"
      >
        <div className="absolute inset-0 w-full h-full bg-royal-wood border-2 border-royal-gold rounded-md shadow-lg group-hover:shadow-gold-glow transition-all duration-300"></div>
        <div className="absolute inset-1 border border-royal-gold/30 rounded-sm"></div>
        <span className="relative z-10 font-playfair text-xl font-bold text-royal-gold tracking-widest flex items-center gap-3">
          REQUEST ENTRY <Play size={16} fill="currentColor" />
        </span>
      </button>

      {/* Footer Credits */}
      <div className="absolute bottom-8 text-center opacity-40">
        <p className="font-cormorant text-xs text-royal-ivory uppercase tracking-widest mb-1">
          Architected by {DEVELOPER_INFO.name}
        </p>
        <p className="font-lora text-[10px] text-royal-gold-dark">
          {DEVELOPER_INFO.title} • Age: {DEVELOPER_INFO.age}
        </p>
      </div>
    </div>
  );
};

export default StartScreen;
