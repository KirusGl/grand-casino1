import React from 'react';
import { Card } from '../../utils/cardUtils';
import { Heart, Diamond, Club, Spade } from 'lucide-react';

interface PlayingCardProps {
  card?: Card;
  hidden?: boolean;
  className?: string;
  selected?: boolean;
  onClick?: () => void;
}

const PlayingCard: React.FC<PlayingCardProps> = ({ card, hidden, className = '', selected, onClick }) => {
  // ADAPTIV: Using vw for mobile width, capped by max-width in rem for desktop
  // clamp() ensures fonts are readable on small screens but don't explode on large ones
  const baseClasses = `
    relative rounded-lg shadow-xl select-none transition-transform duration-200
    w-[18vw] h-[26vw] max-w-[5rem] max-h-[7.5rem] md:w-[6rem] md:h-[8.5rem]
    flex items-center justify-center overflow-hidden border border-gray-200
    ${selected ? 'ring-2 ring-royal-gold -translate-y-2 z-10' : 'hover:-translate-y-1'}
    ${onClick ? 'cursor-pointer' : ''}
    ${className}
  `;

  // Back of card
  if (hidden || !card) {
    return (
      <div className={`${baseClasses} bg-[#1a1a1a] border-white/10`}>
        <div className="absolute inset-1 border border-royal-gold/40 rounded opacity-80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-royal-gold/20 via-transparent to-transparent" />
        {/* ADAPTIV: Font size relative to card width */}
        <div className="text-royal-gold font-playfair font-bold text-[clamp(1rem,4vw,1.5rem)]">R</div>
      </div>
    );
  }

  const isRed = card.suit === 'hearts' || card.suit === 'diamonds';
  const Icon = card.suit === 'hearts' ? Heart : card.suit === 'diamonds' ? Diamond : card.suit === 'clubs' ? Club : Spade;

  return (
    <div onClick={onClick} className={`${baseClasses} bg-[#fdfbf7]`}>
      {/* ADAPTIV: Positioning using % to stay safe within borders */}
      <div className={`absolute top-[6%] left-[6%] flex flex-col items-center leading-none ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
        <span className="font-playfair font-bold text-[clamp(0.6rem,2.5vw,1rem)]">{card.rank}</span>
        <Icon className="w-[2.5vw] h-[2.5vw] max-w-[12px] max-h-[12px] mt-[2px]" fill="currentColor" />
      </div>

      <div className={`flex items-center justify-center ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
         {['J', 'Q', 'K', 'A'].includes(card.rank) ? (
             <div className="font-playfair font-black text-[clamp(1.2rem,5vw,2rem)] opacity-90 border-2 border-current rounded px-1">
                 {card.rank}
             </div>
         ) : (
             <Icon className="w-[8vw] h-[8vw] max-w-[32px] max-h-[32px]" fill="currentColor" />
         )}
      </div>

      <div className={`absolute bottom-[6%] right-[6%] flex flex-col items-center leading-none rotate-180 ${isRed ? 'text-[#d40000]' : 'text-[#1a1a1a]'}`}>
        <span className="font-playfair font-bold text-[clamp(0.6rem,2.5vw,1rem)]">{card.rank}</span>
        <Icon className="w-[2.5vw] h-[2.5vw] max-w-[12px] max-h-[12px] mt-[2px]" fill="currentColor" />
      </div>
    </div>
  );
};

export default PlayingCard;