import React, { useState } from 'react';
import { GameType } from '../types';
import { Dice5, CircleDollarSign, Spade, Club, Gem, LayoutGrid, Hash, Tv, Rocket, Bomb, Layers, ArrowLeft, Crown, Coins } from 'lucide-react';

interface LobbyScreenProps {
  onSelectGame: (game: GameType) => void;
  userName: string;
  balance: number;
}

const MAIN_GAMES = [
  { id: GameType.ROULETTE, name: 'Roulette', icon: CircleDollarSign, desc: 'European Wheel' },
  { id: GameType.ROCKET, name: 'Royal Rocket', icon: Rocket, desc: 'High Stakes Crash' },
  { id: GameType.MINES, name: 'Royal Mines', icon: Bomb, desc: 'Diamond Hunt' },
  { id: GameType.SLOTS, name: 'Slots', icon: LayoutGrid, desc: 'Royal 777' },
  { id: GameType.CRAPS, name: 'Craps', icon: Dice5, desc: 'Roll the bones' },
  { id: GameType.KENO, name: 'Keno', icon: Hash, desc: 'Pick your lucky numbers' },
];

const CARD_GAMES = [
  { id: GameType.DURAK, name: 'Durak', icon: Crown, desc: 'The Fool (Russian)' },
  { id: GameType.BLACKJACK, name: 'Blackjack', icon: Spade, desc: 'Dealer stands on 17' },
  { id: GameType.POKER, name: 'Casino Poker', icon: Club, desc: 'Caribbean Stud' },
  { id: GameType.BACCARAT, name: 'Baccarat', icon: Gem, desc: 'Punto Banco' },
  { id: GameType.VIDEO_POKER, name: 'Video Poker', icon: Tv, desc: 'Jacks or Better' },
];

const LobbyScreen: React.FC<LobbyScreenProps> = ({ onSelectGame, userName, balance }) => {
  const [currentView, setCurrentView] = useState<'MAIN' | 'CARDS'>('MAIN');

  const renderGameButton = (game: any) => (
    <button
      key={game.id}
      onClick={() => onSelectGame(game.id)}
      className="group relative bg-royal-wood/80 border border-royal-gold/30 rounded-xl p-4 flex flex-col items-center justify-center gap-2 hover:border-royal-gold hover:shadow-gold-glow transition-all active:scale-95 h-32"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-royal-gold/5 to-transparent rounded-xl"></div>
      <game.icon className="text-royal-gold w-8 h-8 group-hover:scale-110 transition-transform" strokeWidth={1.5} />
      <div className="text-center z-10">
        <span className="block font-playfair font-bold text-royal-ivory text-lg">{game.name}</span>
        <span className="block font-lora text-royal-gold-dark text-[10px] uppercase tracking-wider">{game.desc}</span>
      </div>
    </button>
  );

  return (
    <div className="flex flex-col h-screen w-full bg-royal-bg bg-felt-pattern p-4 animate-fade-in overflow-y-auto">
      <div className="text-center mb-6 mt-4 relative">
        {currentView === 'CARDS' && (
          <button 
            onClick={() => setCurrentView('MAIN')} 
            className="absolute left-0 top-1/2 -translate-y-1/2 p-2 text-royal-gold hover:text-white"
          >
            <ArrowLeft size={24} />
          </button>
        )}
        <h2 className="text-3xl font-playfair font-bold text-royal-gold gold-text-gradient">
          {currentView === 'MAIN' ? 'Grand Lobby' : 'Royal Cards'}
        </h2>
        <div className="h-px w-24 bg-royal-gold mx-auto my-2 opacity-50"></div>
        <p className="font-cormorant text-royal-ivory text-sm opacity-80 mb-3">
          {currentView === 'MAIN' ? `Select your table, ${userName}` : 'High Stakes Card Room'}
        </p>
        
        {/* Balance Display */}
        <div className="inline-flex items-center gap-2 bg-black/40 px-4 py-2 rounded-full border border-royal-gold/30 backdrop-blur-sm shadow-inner-depth">
            <Coins className="text-royal-gold" size={16} />
            <span className="font-lora font-bold text-lg text-royal-ivory">{balance.toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 pb-20 max-w-md mx-auto w-full">
        {currentView === 'MAIN' ? (
          <>
            {MAIN_GAMES.map(renderGameButton)}
            
            {/* Folder for Card Games */}
            <button
              onClick={() => setCurrentView('CARDS')}
              className="group relative bg-royal-wood border border-royal-gold/50 rounded-xl p-4 flex flex-col items-center justify-center gap-2 hover:border-royal-gold hover:shadow-gold-glow transition-all active:scale-95 h-32"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-royal-gold/10 to-transparent rounded-xl"></div>
              {/* Stack effect */}
              <div className="absolute top-3 right-3 w-4 h-4 bg-royal-ivory/10 rounded-sm rotate-12"></div>
              
              <Layers className="text-royal-ivory w-8 h-8 group-hover:scale-110 transition-transform" strokeWidth={1.5} />
              <div className="text-center z-10">
                <span className="block font-playfair font-bold text-royal-gold text-lg">Card Games</span>
                <span className="block font-lora text-royal-ivory/60 text-[10px] uppercase tracking-wider">Poker, Blackjack...</span>
              </div>
            </button>
          </>
        ) : (
          <>
            {CARD_GAMES.map(renderGameButton)}
          </>
        )}
      </div>
    </div>
  );
};

export default LobbyScreen;