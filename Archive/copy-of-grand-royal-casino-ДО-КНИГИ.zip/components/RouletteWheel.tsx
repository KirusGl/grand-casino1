import React, { useMemo } from 'react';
import { WHEEL_NUMBERS, RED_NUMBERS } from '../constants';

interface RouletteWheelProps {
  rotation: number;
  isSpinning: boolean;
  targetNumber?: number | null;
}

const RouletteWheel: React.FC<RouletteWheelProps> = ({ rotation, isSpinning }) => {
  const numSectors = WHEEL_NUMBERS.length;
  const sectorAngle = 360 / numSectors;

  // ADAPTIV: Use simple CSS conic gradient for sectors to avoid heavy DOM elements
  const conicGradient = useMemo(() => {
    let gradient = 'conic-gradient(';
    WHEEL_NUMBERS.forEach((num, i) => {
      let color = '#1a1a1a'; 
      if (num === 0) color = '#006400'; 
      else if (RED_NUMBERS.includes(num)) color = '#8B0000';
      
      const start = i * sectorAngle;
      const end = (i + 1) * sectorAngle;
      gradient += `${color} ${start}deg ${end}deg, `;
    });
    return gradient.slice(0, -2) + ')';
  }, [sectorAngle]);

  return (
    // ADAPTIV: Container is 100% of parent, aspect ratio ensures square
    <div className="relative w-full h-full aspect-square flex items-center justify-center">
      
      {/* 1. OUTER RIM */}
      <div className="absolute inset-0 rounded-full border-[clamp(8px,3vw,16px)] border-[#d4af37] shadow-xl z-20 pointer-events-none"></div>

      {/* 2. SPINNING CONTAINER */}
      <div
        className="relative w-[92%] h-[92%] rounded-full overflow-hidden will-change-transform z-10 shadow-inner"
        style={{
          transform: `rotate(${rotation}deg)`,
          transition: isSpinning ? 'transform 4s cubic-bezier(0.15, 0, 0.15, 1)' : 'transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1)',
        }}
      >
        {/* Sectors */}
        <div className="absolute inset-0 rounded-full" style={{ background: conicGradient }} />
        
        {/* Numbers (Positioned absolutely using percentages) */}
        {WHEEL_NUMBERS.map((num, i) => {
             const angle = (i + 0.5) * sectorAngle;
             return (
                 <div
                    key={num}
                    className="absolute top-1/2 left-1/2 text-white font-bold origin-center"
                    style={{
                        // Logic: Move to center, Rotate, Move OUT (TranslateY negative), Rotate back text if needed (omitted for simple radial view)
                        transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-42%)`,
                        height: '100%',
                        // ADAPTIV: Font size relative to container
                        fontSize: 'clamp(8px, 2.5cqw, 14px)' 
                    }}
                 >
                    <span className="block pt-1">{num}</span>
                 </div>
             )
        })}

        {/* Inner Hub */}
        <div className="absolute inset-0 m-auto w-[60%] h-[60%] bg-[#050a08] rounded-full border border-[#d4af37]/30 flex items-center justify-center shadow-[0_0_15px_black]">
            <div className="w-[20%] h-[20%] bg-gradient-to-br from-[#d4af37] to-[#8a6e2f] rounded-full shadow-lg"></div>
        </div>
      </div>

      {/* 3. INDICATOR */}
      <div className="absolute -top-[2%] left-1/2 -translate-x-1/2 z-30 drop-shadow-lg">
        <div className="w-0 h-0 border-l-[8px] border-r-[8px] border-t-[16px] border-transparent border-t-[#f8f3e6]"></div>
      </div>
    </div>
  );
};

export default RouletteWheel;