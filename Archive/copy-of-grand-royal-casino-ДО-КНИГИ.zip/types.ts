export enum GameState {
  START = 'START',
  LOBBY = 'LOBBY',
  PLAYING = 'PLAYING',
  RESULT = 'RESULT'
}

export enum GameType {
  ROULETTE = 'ROULETTE',
  BLACKJACK = 'BLACKJACK',
  POKER = 'POKER', // Casino Hold'em
  BACCARAT = 'BACCARAT',
  CRAPS = 'CRAPS',
  SLOTS = 'SLOTS',
  VIDEO_POKER = 'VIDEO_POKER',
  KENO = 'KENO',
  ROCKET = 'ROCKET', // Crash Game
  MINES = 'MINES',   // Royal Mines
  DURAK = 'DURAK'    // Durak (Fool)
}

export type BetType = 'RED' | 'BLACK' | 'GREEN' | null;

export interface Bet {
  type: BetType;
  amount: number;
}

export interface GameSessionResult {
  finalBalance: number;
  totalWon: number;
  timestamp: number;
}

// Telegram WebApp Type Definition (Partial)
export interface TelegramWebApp {
  ready: () => void;
  expand: () => void;
  close: () => void;
  sendData: (data: string) => void;
  MainButton: {
    text: string;
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
  };
  setHeaderColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  initDataUnsafe?: {
    user?: {
      first_name: string;
      last_name?: string;
      username?: string;
    }
  }
}