import React, { useState } from 'react';
import { GameType } from '../types';
import { 
  Dice5, CircleDollarSign, Spade, Club, Gem, LayoutGrid, Hash, Tv, 
  Rocket, Bomb, Layers, ArrowLeft, BookOpen, Scroll, Armchair 
} from 'lucide-react';

interface LobbyScreenProps {
  onSelectGame: (game: GameType) => void;
  userName: string;
  balance: number;
}

const MAIN_GAMES = [
  { id: GameType.ROULETTE, name: 'Dynasty Roulette', icon: CircleDollarSign, desc: 'The Classic Wheel' },
  { id: GameType.ROCKET, name: 'Aviation Club', icon: Rocket, desc: 'Ascend to heights' },
  { id: GameType.MINES, name: 'Royal Treasury', icon: Bomb, desc: 'Secure the diamonds' },
  { id: GameType.SLOTS, name: 'Heritage Slots', icon: LayoutGrid, desc: 'Family Fortunes' },
  { id: GameType.CRAPS, name: 'Dice Parlour', icon: Dice5, desc: 'Gentlemans Wager' },
  { id: GameType.KENO, name: 'Numerology', icon: Hash, desc: 'Destiny awaits' },
];

const CARD_GAMES = [
  { id: GameType.DURAK, name: 'The Tsar', icon: Scroll, desc: 'Imperial Durak' },
  { id: GameType.BLACKJACK, name: 'Privé 21', icon: Spade, desc: 'Dealer stands on 17' },
  { id: GameType.POKER, name: 'Poker Salon', icon: Club, desc: 'Texas & Caribbean' },
  { id: GameType.BACCARAT, name: 'Baccarat Room', icon: Gem, desc: 'High Rollers Only' },
  { id: GameType.VIDEO_POKER, name: 'Automaton Poker', icon: Tv, desc: 'Mechanical Skill' },
];

const LobbyScreen: React.FC<LobbyScreenProps> = ({ onSelectGame, userName, balance }) => {
  const [currentView, setCurrentView] = useState<'MAIN' | 'CARDS'>('MAIN');

  const renderGameCard = (game: any) => (
    <button
      key={game.id}
      onClick={() => onSelectGame(game.id)}
      className="group relative w-full h-36 bg-om-wood bg-wood-texture border border-om-gold/20 shadow-xl overflow-hidden transition-all duration-500 hover:-translate-y-1 hover:shadow-2xl active:scale-[0.98]"
    >
      {/* Card Visuals */}
      <div className="absolute top-0 left-0 w-full h-1 bg-om-gold/40"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80"></div>
      
      <div className="relative z-10 h-full flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 mb-3 rounded-full border border-om-gold/30 flex items-center justify-center bg-black/20 group-hover:bg-om-gold/10 transition-colors duration-500">
           <game.icon className="text-om-gold w-5 h-5 opacity-80 group-hover:opacity-100" strokeWidth={1} />
        </div>
        
        <span className="font-cinzel font-bold text-om-cream text-lg tracking-wide text-engraved mb-1">
          {game.name}
        </span>
        
        <span className="font-cormorant italic text-om-gold/60 text-xs tracking-wider">
          {game.desc}
        </span>
      </div>

      {/* Decorative Corners */}
      <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-om-gold/30"></div>
      <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-om-gold/30"></div>
    </button>
  );

  return (
    <div className="flex flex-col h-screen w-full bg-om-wine bg-leather-texture animate-slow-fade overflow-hidden">
      
      {/* Header / Concierge */}
      <div className="pt-safe px-6 pb-6 bg-gradient-to-b from-black/60 to-transparent z-20 shadow-lg">
        <div className="flex justify-between items-end mb-6">
            <div>
                 <p className="font-cormorant text-om-gold/60 italic text-sm mb-1">Welcome back,</p>
                 <h2 className="font-cinzel text-2xl text-om-cream tracking-widest">{userName}</h2>
            </div>
            <div className="text-right">
                <p className="font-cormorant text-om-gold/60 italic text-sm mb-1">Account Balance</p>
                <div className="font-playfair text-xl text-om-gold font-bold tracking-wider border-b border-om-gold/30 pb-1">
                    ${balance.toLocaleString()}
                </div>
            </div>
        </div>

        <div className="relative text-center">
            {currentView === 'CARDS' && (
            <button 
                onClick={() => setCurrentView('MAIN')} 
                className="absolute left-0 top-1/2 -translate-y-1/2 text-om-gold/70 hover:text-om-gold transition-colors"
            >
                <ArrowLeft size={22} strokeWidth={1} />
            </button>
            )}
            <span className="font-cinzel text-lg text-om-cream/80 border px-6 py-1 border-om-gold/20 rounded-sm bg-black/20 backdrop-blur-md">
                {currentView === 'MAIN' ? 'The Great Hall' : 'Private Card Room'}
            </span>
        </div>
      </div>

      {/* Scrollable Content (The Library) */}
      <div className="flex-1 overflow-y-auto px-6 pb-24 scrollbar-hide">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto pt-2">
          
          {currentView === 'MAIN' ? (
            <>
              {MAIN_GAMES.map(renderGameCard)}
              
              {/* Card Room Entry */}
              <button
                onClick={() => setCurrentView('CARDS')}
                className="group relative w-full h-36 bg-om-emerald bg-felt-texture border-2 border-double border-om-gold/20 shadow-xl overflow-hidden transition-all duration-500 hover:border-om-gold/50"
              >
                 <div className="absolute inset-0 bg-black/40"></div>
                 <div className="relative z-10 h-full flex flex-col items-center justify-center">
                    <BookOpen className="text-om-cream w-8 h-8 mb-2 opacity-70 group-hover:opacity-100 transition-opacity" strokeWidth={1} />
                    <span className="font-cinzel font-bold text-om-cream text-xl tracking-widest text-engraved">
                        Card Collections
                    </span>
                    <span className="font-cormorant italic text-om-gold text-xs mt-1">
                        Tap to enter the Private Room
                    </span>
                 </div>
              </button>
            </>
          ) : (
            <>
              {CARD_GAMES.map(renderGameCard)}
            </>
          )}

          {/* Decorative Bottom Element */}
          <div className="col-span-1 md:col-span-2 flex justify-center py-8 opacity-30">
             <Armchair size={24} className="text-om-gold" strokeWidth={1} />
          </div>

        </div>
      </div>
    </div>
  );
};

export default LobbyScreen;