import React from 'react';
import { GameType } from '../types';
import { ArrowLeft, X } from 'lucide-react';
import RouletteGame from './games/RouletteGame';
import BlackjackGame from './games/BlackjackGame';
import SlotsGame from './games/SlotsGame';
import PokerGame from './games/PokerGame';
import BaccaratGame from './games/BaccaratGame';
import CrapsGame from './games/CrapsGame';
import VideoPokerGame from './games/VideoPokerGame';
import KenoGame from './games/KenoGame';
import RocketGame from './games/RocketGame';
import MinesGame from './games/MinesGame';
import DurakGame from './games/DurakGame';

interface GameScreenProps {
  gameType: GameType;
  balance: number;
  onUpdateBalance: (delta: number) => void;
  onBackToLobby: () => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ gameType, balance, onUpdateBalance, onBackToLobby }) => {
  
  const renderGame = () => {
    const props = {
      balance,
      onUpdateBalance,
    };

    switch (gameType) {
      case GameType.ROULETTE: return <RouletteGame {...props} />;
      case GameType.BLACKJACK: return <BlackjackGame {...props} />;
      case GameType.SLOTS: return <SlotsGame {...props} />;
      case GameType.POKER: return <PokerGame {...props} />;
      case GameType.BACCARAT: return <BaccaratGame {...props} />;
      case GameType.CRAPS: return <CrapsGame {...props} />;
      case GameType.VIDEO_POKER: return <VideoPokerGame {...props} />;
      case GameType.KENO: return <KenoGame {...props} />;
      case GameType.ROCKET: return <RocketGame {...props} />;
      case GameType.MINES: return <MinesGame {...props} />;
      case GameType.DURAK: return <DurakGame {...props} />;
      default: return <div>Game Under Construction</div>;
    }
  };

  return (
    // "Leather Notebook" aesthetic wrapper
    <div className="flex flex-col h-screen bg-om-leather bg-leather-texture overflow-hidden relative shadow-[inset_0_0_80px_rgba(0,0,0,1)]">
        
      {/* Stitching Effect Left/Right */}
      <div className="absolute top-0 bottom-0 left-2 w-px border-l-2 border-dashed border-om-wood/50 opacity-30 pointer-events-none z-50"></div>
      <div className="absolute top-0 bottom-0 right-2 w-px border-r-2 border-dashed border-om-wood/50 opacity-30 pointer-events-none z-50"></div>

      {/* Top Bar - Engraved Metal Plate Look */}
      <div className="relative z-30 pt-safe px-4 pb-2 bg-gradient-to-b from-[#2a2a2a] to-[#1a1a1a] border-b border-om-gold/30 shadow-lg">
        <div className="flex justify-between items-center h-14">
            
            <button 
                onClick={onBackToLobby} 
                className="flex items-center gap-2 text-om-gold/70 hover:text-om-cream transition-colors group"
            >
                <div className="border border-om-gold/20 rounded-sm p-1 group-hover:border-om-gold/50">
                    <ArrowLeft size={18} strokeWidth={1} />
                </div>
                <span className="font-cinzel text-xs tracking-widest uppercase hidden md:inline">Exit Salon</span>
            </button>
            
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pt-safe">
                 <span className="font-cinzel font-bold text-om-gold text-lg tracking-[0.2em] opacity-80 text-engraved">
                    {gameType.replace('_', ' ')}
                 </span>
            </div>

            <div className="flex items-center gap-3">
               <div className="text-right">
                   <span className="block font-cormorant text-[10px] text-om-gold/50 uppercase tracking-widest">Credit</span>
                   <span className="block font-playfair font-bold text-om-cream text-lg leading-none">${balance.toLocaleString()}</span>
               </div>
            </div>
        </div>
      </div>

      {/* Game Content - The "Paper" or "Felt" Surface inside the notebook */}
      <div className="flex-1 overflow-hidden relative bg-om-emerald bg-felt-texture shadow-inner">
         {/* Vignette */}
         <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_50px_rgba(0,0,0,0.8)] z-10"></div>
         
         <div className="relative z-0 h-full w-full">
            {renderGame()}
         </div>
      </div>
    </div>
  );
};

export default GameScreen;