import React from 'react';
import { DEVELOPER_INFO } from '../constants';
import { KeyRound, Crown } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
  userName: string;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart, userName }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen w-full bg-om-wine bg-leather-texture relative p-8 text-center animate-slow-fade shadow-[inset_0_0_100px_rgba(0,0,0,0.9)]">
      
      {/* Golden Frame Border */}
      <div className="absolute inset-4 border-double border-4 border-om-gold/30 rounded-lg pointer-events-none" />
      <div className="absolute inset-6 border border-om-gold/10 rounded-sm pointer-events-none" />

      {/* Main Content Card */}
      <div className="relative z-10 max-w-sm w-full bg-om-wine/90 backdrop-blur-sm p-8 border border-om-gold/20 shadow-2xl rounded-sm">
        
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-full border-2 border-om-gold flex items-center justify-center bg-om-emerald shadow-lg">
             <Crown size={32} className="text-om-gold" strokeWidth={1} />
          </div>
        </div>

        <h1 className="text-4xl md:text-5xl font-cinzel font-bold tracking-widest uppercase mb-4 text-om-gold text-engraved">
          The<br/>Residency
        </h1>

        <div className="h-px w-16 bg-om-gold mx-auto mb-6 opacity-60"></div>

        <p className="font-cormorant text-om-cream text-xl italic tracking-wide mb-8 opacity-90 leading-relaxed">
          "A digital sanctuary for the uncompromising few."
        </p>

        <div className="mb-10 text-sm font-playfair text-om-gold/70 uppercase tracking-[0.2em]">
          Invitation for<br/>
          <span className="text-om-cream text-lg border-b border-om-gold/30 pb-1 inline-block mt-2">{userName}</span>
        </div>

        {/* Engraved Button */}
        <button
          onClick={onStart}
          className="group relative w-full py-4 bg-om-wood overflow-hidden rounded-sm transition-all duration-700 shadow-embossed hover:shadow-lg active:shadow-engraved"
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"></div>
          <div className="absolute inset-0 border border-om-gold/20 opacity-50 group-hover:opacity-100 transition-opacity"></div>
          
          <span className="relative z-10 font-cinzel text-lg text-om-gold flex items-center justify-center gap-3 tracking-widest group-hover:text-om-cream transition-colors duration-500">
            <KeyRound size={18} /> ENTER SALON
          </span>
        </button>
      </div>

      {/* Footer */}
      <div className="absolute bottom-6 text-center opacity-30">
        <p className="font-cormorant text-[10px] text-om-cream uppercase tracking-[0.3em] mb-1">
          Est. 1897 • Private Members Only
        </p>
      </div>
    </div>
  );
};

export default StartScreen;