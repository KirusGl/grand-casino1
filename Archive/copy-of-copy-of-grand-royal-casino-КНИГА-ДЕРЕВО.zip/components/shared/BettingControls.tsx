import React, { useEffect, useState } from 'react';
import { CHIP_VALUES } from '../../constants';
import { Plus, Minus } from 'lucide-react';

interface BettingControlsProps {
  balance: number;
  currentBet: number;
  onBetChange: (amount: number) => void;
  onAction?: () => void;
  actionLabel?: string; 
  isGameActive?: boolean;
  minBet?: number;
  maxBet?: number;
  chipMode?: boolean; 
  children?: React.ReactNode; 
}

const BettingControls: React.FC<BettingControlsProps> = ({
  balance,
  currentBet,
  onBetChange,
  onAction,
  actionLabel = "PLAY",
  isGameActive = false,
  minBet = 10,
  maxBet = balance,
  chipMode = false,
  children
}) => {
  const [inputValue, setInputValue] = useState(currentBet.toString());

  useEffect(() => {
    setInputValue(currentBet.toString());
  }, [currentBet]);

  const handleValidation = (val: number) => {
    if (isNaN(val)) return;
    let newBet = Math.max(0, val);
    if (!chipMode) {
        newBet = Math.min(newBet, balance);
    }
    onBetChange(newBet);
  };

  const handleManualInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    const val = parseInt(e.target.value);
    if (!isNaN(val)) handleValidation(val);
  };

  const adjustBet = (delta: number) => handleValidation(currentBet + delta);
  const setExactBet = (amount: number) => handleValidation(amount);
  const handleMax = () => handleValidation(balance);

  return (
    // Panel looks like dark polished wood with gold trim
    <div className="w-full bg-om-wood/95 bg-wood-texture border-t-2 border-om-gold/40 p-4 pb-safe shadow-[0_-10px_30px_rgba(0,0,0,0.8)] z-40 relative">
      <div className="max-w-md mx-auto w-full flex flex-col gap-4">
        
        {children && <div className="mb-1">{children}</div>}

        {/* Chip/Preset Row - Styling chips like physical tokens */}
        <div className="flex justify-between gap-3 overflow-x-auto scrollbar-hide py-1">
          {CHIP_VALUES.map((val) => (
            <button
              key={val}
              disabled={isGameActive}
              onClick={() => setExactBet(val)}
              className={`
                flex-1 min-w-[3.5rem] h-12 rounded-full font-bold font-playfair text-sm transition-all duration-300
                flex items-center justify-center border-2 shadow-lg
                ${currentBet === val 
                  ? 'bg-om-gold text-om-wine border-om-cream scale-110 shadow-gold-glow' 
                  : 'bg-om-wine text-om-gold border-om-gold/30 opacity-80 hover:opacity-100'}
              `}
            >
              {val}
            </button>
          ))}
          {!chipMode && (
             <button 
                onClick={handleMax}
                disabled={isGameActive} 
                className="px-4 h-12 rounded-lg bg-transparent border border-om-gold/40 text-om-gold font-cinzel text-xs tracking-widest hover:bg-om-gold/10 transition-colors uppercase"
             >
                MAX
             </button>
          )}
        </div>

        {/* Input & Action Row */}
        <div className="flex gap-3 h-14">
            {/* Input Group - Metal Plate Style */}
            <div className="flex-1 flex bg-[#1a1a1a] rounded-sm border border-om-gold/20 shadow-inner relative">
                <button 
                    onClick={() => adjustBet(-10)} 
                    disabled={isGameActive || currentBet <= minBet}
                    className="w-12 flex items-center justify-center text-om-gold/60 hover:text-om-gold active:bg-white/5 transition-colors border-r border-white/5"
                >
                    <Minus size={18} />
                </button>
                
                <div className="flex-1 relative flex items-center justify-center">
                    <span className="absolute left-3 text-om-gold/30 font-serif italic">$</span>
                    <input
                        type="number"
                        value={inputValue}
                        onChange={handleManualInput}
                        disabled={isGameActive}
                        className="w-full h-full bg-transparent text-center text-om-cream font-playfair font-bold text-xl outline-none px-4"
                        placeholder="0"
                    />
                </div>

                <button 
                    onClick={() => adjustBet(10)} 
                    disabled={isGameActive || (!chipMode && currentBet >= balance)}
                    className="w-12 flex items-center justify-center text-om-gold/60 hover:text-om-gold active:bg-white/5 transition-colors border-l border-white/5"
                >
                    <Plus size={18} />
                </button>
            </div>

            {/* Action Button - Heavy Engraved Gold/Metal */}
            {onAction && (
                <button
                    onClick={onAction}
                    disabled={isGameActive || (!chipMode && (currentBet > balance || currentBet < minBet))}
                    className={`
                        flex-[1.2] rounded-sm font-cinzel font-bold text-lg tracking-widest shadow-embossed transition-all active:scale-[0.98] active:shadow-engraved flex items-center justify-center border border-om-gold/30
                        ${isGameActive 
                            ? 'bg-om-metal/20 text-om-metal cursor-not-allowed' 
                            : 'bg-gradient-to-b from-om-gold to-[#8a6e2f] text-[#2a1a0a] hover:brightness-110'}
                    `}
                >
                    {actionLabel}
                </button>
            )}
        </div>
        
      </div>
    </div>
  );
};

export default BettingControls;